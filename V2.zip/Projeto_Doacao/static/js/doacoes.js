document.addEventListener('DOMContentLoaded', () => {
    carregarInformacoesUsuario();
    carregarDoacoes();
    carregarSolicitacoes();
    carregarItensDisponiveis();
    carregarCampanhas();
    verificarNotificacoes();

    // Event Listeners - Logout
    document.getElementById('logout-link').addEventListener('click', realizarLogout);

    // Event Listeners - Doação
    document.getElementById('nova-doacao-btn').addEventListener('click', () => {
        document.getElementById('form-doacao').style.display = 'block';
    });
    document.getElementById('cancelar-doacao').addEventListener('click', () => {
        document.getElementById('form-doacao').style.display = 'none';
        document.getElementById('doacaoForm').reset();
    });
    document.getElementById('doacaoForm').addEventListener('submit', (e) => {
        e.preventDefault();
        enviarDoacao();
    });

    // Event Listeners - Solicitação
    document.getElementById('nova-solicitacao-btn').addEventListener('click', () => {
        document.getElementById('form-solicitacao').style.display = 'block';
    });
    document.getElementById('cancelar-solicitacao').addEventListener('click', () => {
        document.getElementById('form-solicitacao').style.display = 'none';
        document.getElementById('solicitacaoForm').reset();
    });
    document.getElementById('solicitacaoForm').addEventListener('submit', (e) => {
        e.preventDefault();
        enviarSolicitacao();
    });

    // Event Listeners - Campanha
    document.getElementById('nova-campanha-btn').addEventListener('click', () => {
        document.getElementById('form-campanha').style.display = 'block';
        document.getElementById('campanhaForm').reset();
    });
    document.getElementById('cancelar-campanha').addEventListener('click', () => {
        document.getElementById('form-campanha').style.display = 'none';
        document.getElementById('campanhaForm').reset();
    });
    document.getElementById('campanhaForm').addEventListener('submit', (e) => {
        e.preventDefault();
        enviarCampanha();
    });

    // Event Listeners - Filtrar itens disponíveis
    document.getElementById('btn-filtrar').addEventListener('click', () => {
        carregarItensDisponiveis(document.getElementById('filtro-categoria').value);
    });

    // Configuração das Abas
    const tabBtns = document.querySelectorAll('.tab-button');
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab-button').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            const tabId = btn.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
});

// Funções de Informações do Usuário
async function carregarInformacoesUsuario() {
    try {
        const response = await fetch('/usuario_info', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error(`Erro ${response.status} ao carregar informações do usuário.`);
        }

        const usuario = await response.json();
        document.getElementById('usuario-nome').textContent = usuario.nome;
    } catch (error) {
        console.error('Erro ao carregar informações do usuário:', error);
        document.getElementById('usuario-nome').textContent = 'Usuário';
    }
}

// Funções de Gestão de Doações
async function carregarDoacoes() {
    document.getElementById('mensagem-carregando-doacoes').style.display = 'block';
    document.getElementById('tabela-doacoes').style.display = 'none';
    document.getElementById('sem-doacoes').style.display = 'none';

    try {
        const response = await fetch('/doacoes', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error(`Erro ${response.status} ao carregar doações.`);
        }

        const doacoes = await response.json();
        
        document.getElementById('mensagem-carregando-doacoes').style.display = 'none';
        
        if (doacoes.length === 0) {
            document.getElementById('sem-doacoes').style.display = 'block';
        } else {
            renderizarDoacoes(doacoes);
            document.getElementById('tabela-doacoes').style.display = 'table';
        }
    } catch (error) {
        console.error('Erro ao carregar doações:', error);
        document.getElementById('mensagem-carregando-doacoes').style.display = 'none';
        document.getElementById('sem-doacoes').textContent = `Erro ao carregar doações: ${error.message}`;
        document.getElementById('sem-doacoes').style.display = 'block';
    }
}

function renderizarDoacoes(doacoes) {
    const tbody = document.getElementById('doacoes-lista');
    tbody.innerHTML = '';

    doacoes.forEach(doacao => {
        const tr = document.createElement('tr');
        
        // Formata a data para o formato brasileiro
        const dataFormatada = doacao.data_doacao ? new Date(doacao.data_doacao).toLocaleDateString('pt-BR') : '-';
        
        tr.innerHTML = `
            <td>${doacao.nome || '-'}</td>
            <td>${doacao.descricao || '-'}</td>
            <td>${doacao.categoria ? doacao.categoria.charAt(0).toUpperCase() + doacao.categoria.slice(1) : '-'}</td>
            <td>${doacao.quantidade || 0}</td>
            <td>${dataFormatada}</td>
            <td>
                <button class="btn-small btn-danger" onclick="excluirDoacao(${doacao.id})">Excluir</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

async function enviarDoacao() {
    const form = document.getElementById('doacaoForm');
    const formData = new FormData(form);
    const dadosDoacao = Object.fromEntries(formData.entries());
    
    try {
        const response = await fetch('/doacoes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dadosDoacao),
            credentials: 'include'
        });

        if (!response.ok) {
            const erro = await response.json();
            throw new Error(erro.error || `Erro ${response.status} ao cadastrar doação.`);
        }

        form.reset();
        document.getElementById('form-doacao').style.display = 'none';
        await carregarDoacoes();
        alert('Doação cadastrada com sucesso!');
    } catch (error) {
        console.error('Erro ao enviar doação:', error);
        alert(`Erro ao cadastrar doação: ${error.message}`);
    }
}

async function excluirDoacao(id) {
    if (!confirm('Tem certeza que deseja excluir esta doação?')) {
        return;
    }

    try {
        const response = await fetch(`/doacoes/${id}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!response.ok) {
            const erro = await response.json();
            throw new Error(erro.error || `Erro ${response.status} ao excluir doação.`);
        }

        await carregarDoacoes();
        alert('Doação excluída com sucesso!');
    } catch (error) {
        console.error('Erro ao excluir doação:', error);
        alert(`Erro ao excluir doação: ${error.message}`);
    }
}

// Funções de Gestão de Solicitações
async function carregarSolicitacoes() {
    document.getElementById('mensagem-carregando-solicitacoes').style.display = 'block';
    document.getElementById('tabela-solicitacoes').style.display = 'none';
    document.getElementById('sem-solicitacoes').style.display = 'none';

    try {
        const response = await fetch('/solicitacoes', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error(`Erro ${response.status} ao carregar solicitações.`);
        }

        const solicitacoes = await response.json();
        
        document.getElementById('mensagem-carregando-solicitacoes').style.display = 'none';
        
        if (solicitacoes.length === 0) {
            document.getElementById('sem-solicitacoes').style.display = 'block';
        } else {
            renderizarSolicitacoes(solicitacoes);
            document.getElementById('tabela-solicitacoes').style.display = 'table';
        }
    } catch (error) {
        console.error('Erro ao carregar solicitações:', error);
        document.getElementById('mensagem-carregando-solicitacoes').style.display = 'none';
        document.getElementById('sem-solicitacoes').textContent = `Erro ao carregar solicitações: ${error.message}`;
        document.getElementById('sem-solicitacoes').style.display = 'block';
    }
}

function renderizarSolicitacoes(solicitacoes) {
    const tbody = document.getElementById('solicitacoes-lista');
    tbody.innerHTML = '';

    solicitacoes.forEach(solicitacao => {
        const tr = document.createElement('tr');
        
        // Formata a data para o formato brasileiro
        const dataFormatada = solicitacao.data_solicitacao ? 
            new Date(solicitacao.data_solicitacao).toLocaleDateString('pt-BR') : '-';
        
        // Define a classe de status para estilização
        const statusClass = solicitacao.status === 'aprovada' ? 'status-aprovada' : 
                          solicitacao.status === 'rejeitada' ? 'status-rejeitada' : 'status-pendente';
        
        // Formata o status para exibição
        const statusFormatado = solicitacao.status ? 
            solicitacao.status.charAt(0).toUpperCase() + solicitacao.status.slice(1) : 'Pendente';
        
        tr.innerHTML = `
            <td>${solicitacao.nome || '-'}</td>
            <td>${solicitacao.descricao || '-'}</td>
            <td>${solicitacao.categoria ? solicitacao.categoria.charAt(0).toUpperCase() + solicitacao.categoria.slice(1) : '-'}</td>
            <td>${solicitacao.quantidade || 0}</td>
            <td>${dataFormatada}</td>
            <td><span class="${statusClass}">${statusFormatado}</span></td>
            <td>
                <button class="btn-small btn-danger" onclick="excluirSolicitacao(${solicitacao.id})">Excluir</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

async function enviarSolicitacao() {
    const form = document.getElementById('solicitacaoForm');
    const formData = new FormData(form);
    const dadosSolicitacao = Object.fromEntries(formData.entries());
    
    try {
        const response = await fetch('/solicitacoes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dadosSolicitacao),
            credentials: 'include'
        });

        if (!response.ok) {
            const erro = await response.json();
            throw new Error(erro.error || `Erro ${response.status} ao cadastrar solicitação.`);
        }

        form.reset();
        document.getElementById('form-solicitacao').style.display = 'none';
        await carregarSolicitacoes();
        alert('Solicitação cadastrada com sucesso!');
    } catch (error) {
        console.error('Erro ao enviar solicitação:', error);
        alert(`Erro ao cadastrar solicitação: ${error.message}`);
    }
}

async function excluirSolicitacao(id) {
    if (!confirm('Tem certeza que deseja excluir esta solicitação?')) {
        return;
    }

    try {
        const response = await fetch(`/solicitacoes/${id}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!response.ok) {
            const erro = await response.json();
            throw new Error(erro.error || `Erro ${response.status} ao excluir solicitação.`);
        }

        await carregarSolicitacoes();
        alert('Solicitação excluída com sucesso!');
    } catch (error) {
        console.error('Erro ao excluir solicitação:', error);
        alert(`Erro ao excluir solicitação: ${error.message}`);
    }
}

// Funções de Itens Disponíveis para Solicitação
async function carregarItensDisponiveis(categoria = '') {
    document.getElementById('mensagem-carregando-disponiveis').style.display = 'block';
    document.getElementById('tabela-disponiveis').style.display = 'none';
    document.getElementById('sem-disponiveis').style.display = 'none';

    try {
        // Construir URL com parâmetro de categoria se fornecido
        let url = '/doacoes/disponiveis';
        if (categoria) {
            url += `?categoria=${encodeURIComponent(categoria)}`;
        }
        
        const response = await fetch(url, {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error(`Erro ${response.status} ao carregar itens disponíveis.`);
        }

        const itens = await response.json();
        
        document.getElementById('mensagem-carregando-disponiveis').style.display = 'none';
        
        if (itens.length === 0) {
            document.getElementById('sem-disponiveis').style.display = 'block';
        } else {
            renderizarItensDisponiveis(itens);
            document.getElementById('tabela-disponiveis').style.display = 'table';
        }
    } catch (error) {
        console.error('Erro ao carregar itens disponíveis:', error);
        document.getElementById('mensagem-carregando-disponiveis').style.display = 'none';
        document.getElementById('sem-disponiveis').textContent = `Erro ao carregar itens disponíveis: ${error.message}`;
        document.getElementById('sem-disponiveis').style.display = 'block';
    }
}

function renderizarItensDisponiveis(itens) {
    const tbody = document.getElementById('disponiveis-lista');
    tbody.innerHTML = '';

    itens.forEach(item => {
        const tr = document.createElement('tr');
        
        // Formata a data para o formato brasileiro
        const dataFormatada = item.data_doacao ? 
            new Date(item.data_doacao).toLocaleDateString('pt-BR') : '-';
        
        tr.innerHTML = `
            <td>${item.nome || '-'}</td>
            <td>${item.descricao || '-'}</td>
            <td>${item.categoria ? item.categoria.charAt(0).toUpperCase() + item.categoria.slice(1) : '-'}</td>
            <td>${item.quantidade || 0}</td>
            <td>${dataFormatada}</td>
            <td>
                <button class="btn-small btn-success" onclick="abrirModalSolicitarItem(${item.id}, '${item.nome}', ${item.quantidade})">Solicitar</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Modal para solicitar um item disponível
function abrirModalSolicitarItem(doacaoId, nomeItem, quantidadeDisponivel) {
    // Criar modal dinamicamente
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'modal-solicitar';
    
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Solicitar Item: ${nomeItem}</h3>
            <form id="formSolicitarItem">
                <input type="hidden" id="doacao-id" value="${doacaoId}">
                <div class="form-group">
                    <label for="quantidade-solicitar">Quantidade (Max: ${quantidadeDisponivel}):</label>
                    <input type="number" id="quantidade-solicitar" min="1" max="${quantidadeDisponivel}" value="1" required>
                </div>
                <div class="form-group">
                    <label for="motivo-solicitar">Motivo da Solicitação:</label>
                    <textarea id="motivo-solicitar" rows="3" required></textarea>
                </div>
                <div class="buttons">
                    <button type="submit" class="btn-success">Confirmar</button>
                    <button type="button" class="btn-secondary" id="cancelar-solicitar">Cancelar</button>
                </div>
            </form>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Exibir modal
    modal.style.display = 'block';
    
    // Fechar modal com X
    const closeBtn = modal.querySelector('.close');
    closeBtn.addEventListener('click', () => {
        document.body.removeChild(modal);
    });
    
    // Fechar modal com botão cancelar
    const cancelarBtn = modal.querySelector('#cancelar-solicitar');
    cancelarBtn.addEventListener('click', () => {
        document.body.removeChild(modal);
    });
    
    // Processar formulário de solicitação
    const form = modal.querySelector('#formSolicitarItem');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const doacaoId = document.getElementById('doacao-id').value;
        const quantidade = document.getElementById('quantidade-solicitar').value;
        const motivo = document.getElementById('motivo-solicitar').value;
        
        try {
            const response = await fetch('/solicitacoes/criar', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    doacao_id: doacaoId,
                    quantidade: quantidade,
                    motivo: motivo
                }),
                credentials: 'include'
            });

            if (!response.ok) {
                const erro = await response.json();
                throw new Error(erro.error || `Erro ${response.status} ao criar solicitação.`);
            }

            // Fechar modal e recarregar informações
            document.body.removeChild(modal);
            await carregarItensDisponiveis();
            await carregarSolicitacoes();
            await verificarNotificacoes();
            alert('Solicitação enviada com sucesso!');
        } catch (error) {
            console.error('Erro ao enviar solicitação:', error);
            alert(`Erro ao enviar solicitação: ${error.message}`);
        }
    });
}

// Funções de Gestão de Campanhas
async function carregarCampanhas() {
    document.getElementById('mensagem-carregando-campanhas').style.display = 'block';
    document.getElementById('tabela-campanhas').style.display = 'none';
    document.getElementById('sem-campanhas').style.display = 'none';

    try {
        const response = await fetch('/campanhas', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error(`Erro ${response.status} ao carregar campanhas.`);
        }

        const campanhas = await response.json();
        
        document.getElementById('mensagem-carregando-campanhas').style.display = 'none';
        
        if (campanhas.length === 0) {
            document.getElementById('sem-campanhas').style.display = 'block';
        } else {
            renderizarCampanhas(campanhas);
            document.getElementById('tabela-campanhas').style.display = 'table';
        }
    } catch (error) {
        console.error('Erro ao carregar campanhas:', error);
        document.getElementById('mensagem-carregando-campanhas').style.display = 'none';
        document.getElementById('sem-campanhas').textContent = `Erro ao carregar campanhas: ${error.message}`;
        document.getElementById('sem-campanhas').style.display = 'block';
    }
}

function renderizarCampanhas(campanhas) {
    const tbody = document.getElementById('campanhas-lista');
    tbody.innerHTML = '';

    campanhas.forEach(campanha => {
        const tr = document.createElement('tr');
        
        // Formata datas (similar ao que você já faz)
        const dataInicioFormatada = campanha.data_inicio ? 
            new Date(campanha.data_inicio + 'T00:00:00').toLocaleDateString('pt-BR') : '-';
        const dataFimFormatada = campanha.data_fim ? 
            new Date(campanha.data_fim + 'T00:00:00').toLocaleDateString('pt-BR') : '-';

        // Formata valores monetários
        const metaFormatada = campanha.meta_financeira != null ? 
            Number(campanha.meta_financeira).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : 'R$ 0,00';
        const arrecadadoFormatado = campanha.valor_arrecadado != null ? 
            Number(campanha.valor_arrecadado).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : 'R$ 0,00';

        // Capitaliza Status
        const statusFormatado = campanha.status ? 
            campanha.status.charAt(0).toUpperCase() + campanha.status.slice(1) : 'Indefinido';

        tr.innerHTML = `
            <td>${campanha.nome || '-'}</td>
            <td>${campanha.descricao || '-'}</td>
            <td>${dataInicioFormatada}</td>
            <td>${dataFimFormatada}</td>
            <td>${metaFormatada}</td>
            <td>${arrecadadoFormatado}</td>
            <td><span class="status-${campanha.status || 'indefinido'}">${statusFormatado}</span></td>
            <td>
                <button class="btn-small btn-danger" onclick="excluirCampanha(${campanha.id})">Excluir</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

async function enviarCampanha() {
    const form = document.getElementById('campanhaForm');
    const formData = new FormData(form);
    const dadosCampanha = Object.fromEntries(formData.entries());

    // Validação simples de data
    if (new Date(dadosCampanha.data_fim) < new Date(dadosCampanha.data_inicio)) {
        alert('A data final não pode ser anterior à data de início.');
        return;
    }

    try {
        const response = await fetch('/campanhas', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dadosCampanha),
            credentials: 'include'
        });

        if (!response.ok) {
            const erro = await response.json();
            throw new Error(erro.error || `Erro ${response.status} ao criar campanha.`);
        }

        form.reset();
        document.getElementById('form-campanha').style.display = 'none';
        await carregarCampanhas();
        alert('Campanha cadastrada com sucesso!');
    } catch (error) {
        console.error('Erro ao enviar campanha:', error);
        alert(`Erro ao cadastrar campanha: ${error.message}`);
    }
}

async function excluirCampanha(id) {
    if (!confirm('Tem certeza que deseja excluir esta campanha?')) {
        return;
    }

    try {
        const response = await fetch(`/campanhas/${id}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!response.ok) {
            const erro = await response.json();
            throw new Error(erro.error || `Erro ${response.status} ao excluir campanha.`);
        }

        await carregarCampanhas();
        alert('Campanha excluída com sucesso!');
    } catch (error) {
        console.error('Erro ao excluir campanha:', error);
        alert(`Erro ao excluir campanha: ${error.message}`);
    }
}

// Funções de notificações
async function verificarNotificacoes() {
    try {
        const response = await fetch('/notificacoes/contagem', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error(`Erro ${response.status} ao verificar notificações.`);
        }

        const data = await response.json();
        const contador = document.getElementById('contador-notificacoes');
        
        if (data.nao_lidas > 0) {
            contador.textContent = data.nao_lidas;
            contador.style.display = 'inline-block';
        } else {
            contador.style.display = 'none';
        }
    } catch (error) {
        console.error('Erro ao verificar notificações:', error);
    }
}

async function realizarLogout() {
    try {
        const response = await fetch('/logout', {
            method: 'POST',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error(`Erro ${response.status} ao realizar logout.`);
        }

        window.location.href = '/login';
    } catch (error) {
        console.error('Erro ao realizar logout:', error);
        alert('Erro ao realizar logout. Tente novamente.');
    }
}

// Disponibiliza funções para uso global
window.excluirDoacao = excluirDoacao;
window.excluirSolicitacao = excluirSolicitacao;
window.excluirCampanha = excluirCampanha;
window.abrirModalSolicitarItem = abrirModalSolicitarItem;
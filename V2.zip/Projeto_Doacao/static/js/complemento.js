<script>
        document.addEventListener('DOMContentLoaded', function() {
            const doacoesContainer = document.getElementById('doacoes-container');
            const loading = document.getElementById('loading');
            const errorMessage = document.getElementById('error-message');
            const semResultados = document.getElementById('sem-resultados');
            const paginationContainer = document.getElementById('pagination');
            const categoriaFilter = document.getElementById('categoria-filter');
            const buscaInput = document.getElementById('busca');
            const filtrarBtn = document.getElementById('filtrar-btn');
            const solicitarModal = document.getElementById('solicitar-modal');
            const modalClose = document.querySelector('.modal-close');
            const solicitarForm = document.getElementById('solicitar-form');
            const logoutBtn = document.getElementById('logout-btn');
            const dashboardToggle = document.getElementById('dashboard-toggle');
            const dashboard = document.getElementById('dashboard');
            const dashboardContent = document.getElementById('dashboard-content');
            
            // Dashboard Charts
            let categoriasChart = null;
            let statusChart = null;
            
            // Verificar se o usuário está logado
            fetch('/usuario_info')
                .then(response => {
                    if (!response.ok) {
                        window.location.href = '/login';
                        throw new Error('Usuário não autenticado');
                    }
                    return response.json();
                })
                .catch(error => {
                    console.error('Erro ao verificar login:', error);
                    window.location.href = '/login';
                });
            
            // Configurações de paginação
            let currentPage = 1;
            const itemsPerPage = 6;
            let allDoacoes = [];
            let dashboardData = {};
            
            // Toggle Dashboard
            dashboardToggle.addEventListener('click', function() {
                const isCollapsed = dashboard.classList.contains('dashboard-collapsed');
                
                if (isCollapsed) {
                    dashboard.classList.remove('dashboard-collapsed');
                    dashboard.classList.add('dashboard-expanded');
                    this.innerHTML = '<i class="fas fa-chevron-up"></i> Minimizar';
                } else {
                    dashboard.classList.remove('dashboard-expanded');
                    dashboard.classList.add('dashboard-collapsed');
                    this.innerHTML = '<i class="fas fa-chevron-down"></i> Expandir';
                }
            });
            
            // Carregar dados do dashboard
            function carregarDashboard() {
                Promise.all([
                    fetch('/doacoes/disponiveis').then(r => r.json()),
                    fetch('/doacoes/estatisticas').then(r => r.ok ? r.json() : { total_doados: 0, total_solicitacoes: 0 })
                ])
                .then(([disponiveis, estatisticas]) => {
                    dashboardData = {
                        disponiveis: disponiveis,
                        estatisticas: estatisticas
                    };
                    
                    atualizarEstatisticas();
                    atualizarGraficos();
                })
                .catch(error => {
                    console.error('Erro ao carregar dashboard:', error);
                });
            }
            
            // Atualizar estatísticas
            function atualizarEstatisticas() {
                const disponiveis = dashboardData.disponiveis || [];
                const estatisticas = dashboardData.estatisticas || {};
                
                // Calcular estatísticas
                const totalDisponiveis = disponiveis.length;
                const totalDoados = estatisticas.total_doados || 0;
                const totalSolicitacoes = estatisticas.total_solicitacoes || 0;
                const categorias = [...new Set(disponiveis.map(d => d.categoria))];
                const totalCategorias = categorias.length;
                
                // Atualizar elementos
                document.getElementById('total-disponiveis').textContent = totalDisponiveis;
                document.getElementById('total-doados').textContent = totalDoados;
                document.getElementById('total-solicitacoes').textContent = totalSolicitacoes;
                document.getElementById('total-categorias').textContent = totalCategorias;
                
                // Animar números
                animateNumbers();
            }
            
            // Animar números
            function animateNumbers() {
                const numbers = document.querySelectorAll('.stat-number');
                numbers.forEach(number => {
                    const target = parseInt(number.textContent);
                    let current = 0;
                    const increment = target / 30;
                    const timer = setInterval(() => {
                        current += increment;
                        if (current >= target) {
                            number.textContent = target;
                            clearInterval(timer);
                        } else {
                            number.textContent = Math.floor(current);
                        }
                    }, 50);
                });
            }
            
            // Atualizar gráficos
            function atualizarGraficos() {
                const disponiveis = dashboardData.disponiveis || [];
                
                // Gráfico de categorias
                atualizarGraficoCategoria(disponiveis);
                
                // Gráfico de status
                atualizarGraficoStatus();
            }
            
            // Gráfico de categorias
            function atualizarGraficoCategoria(disponiveis) {
                const ctx = document.getElementById('categorias-chart').getContext('2d');
                
                // Contar por categoria
                const categorias = {};
                disponiveis.forEach(item => {
                    const cat = item.categoria || 'outros';
                    categorias[cat] = (categorias[cat] || 0) + 1;
                });
                
                const labels = Object.keys(categorias).map(cat => capitalizeFirstLetter(cat));
                const data = Object.values(categorias);
                const colors = [
                    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', 
                    '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F'
                ];
                
                if (categoriasChart) {
                    categoriasChart.destroy();
                }
                
                categoriasChart = new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: labels,
                        datasets: [{
                            data: data,
                            backgroundColor: colors.slice(0, labels.length),
                            borderWidth: 2,
                            borderColor: '#fff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: {
                                    padding: 20,
                                    usePointStyle: true
                                }
                            }
                        }
                    }
                });
            }
            
            // Gráfico de status
            function atualizarGraficoStatus() {
                const ctx = document.getElementById('status-chart').getContext('2d');
                
                const disponiveis = dashboardData.disponiveis ? dashboardData.disponiveis.length : 0;
                const doados = dashboardData.estatisticas ? dashboardData.estatisticas.total_doados : 0;
                
                if (statusChart) {
                    statusChart.destroy();
                }
            }
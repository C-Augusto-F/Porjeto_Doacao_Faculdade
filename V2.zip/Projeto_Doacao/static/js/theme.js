// Script para gerenciar o tema claro/escuro
class ThemeManager {
    constructor() {
        this.currentTheme = this.getStoredTheme() || 'light';
        this.init();
    }

    init() {
        // Aplicar tema inicial
        this.applyTheme(this.currentTheme);
        
        // Criar botão de toggle se não existir
        this.createThemeToggle();
        
        // Adicionar event listeners
        this.addEventListeners();
        
        // Detectar preferência do sistema
        this.detectSystemPreference();
    }

    getStoredTheme() {
        try {
            return localStorage.getItem('theme');
        } catch (error) {
            // Fallback para quando localStorage não estiver disponível
            return null;
        }
    }

    setStoredTheme(theme) {
        try {
            localStorage.setItem('theme', theme);
        } catch (error) {
            // Silenciosamente falha se localStorage não estiver disponível
            console.warn('Não foi possível salvar a preferência de tema');
        }
    }

    createThemeToggle() {
        // Verificar se o botão já existe
        if (document.getElementById('theme-toggle')) {
            return;
        }

        const toggleButton = document.createElement('button');
        toggleButton.id = 'theme-toggle';
        toggleButton.className = 'theme-toggle';
        toggleButton.setAttribute('aria-label', 'Alternar tema');
        toggleButton.innerHTML = this.getThemeIcon(this.currentTheme);
        
        document.body.appendChild(toggleButton);
    }

    getThemeIcon(theme) {
        return theme === 'dark' ? '☀️' : '🌙';
    }

    addEventListeners() {
        const toggleButton = document.getElementById('theme-toggle');
        if (toggleButton) {
            toggleButton.addEventListener('click', () => this.toggleTheme());
        }

        // Escutar mudanças na preferência do sistema
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        mediaQuery.addListener((e) => {
            if (!this.getStoredTheme()) {
                this.applyTheme(e.matches ? 'dark' : 'light');
            }
        });
    }

    detectSystemPreference() {
        if (!this.getStoredTheme()) {
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            this.currentTheme = prefersDark ? 'dark' : 'light';
            this.applyTheme(this.currentTheme);
        }
    }

    toggleTheme() {
        this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
        this.applyTheme(this.currentTheme);
        this.setStoredTheme(this.currentTheme);
        
        // Animação do botão
        this.animateToggleButton();
    }

    applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        this.currentTheme = theme;
        
        // Atualizar ícone do botão
        const toggleButton = document.getElementById('theme-toggle');
        if (toggleButton) {
            toggleButton.innerHTML = this.getThemeIcon(theme);
        }

        // Atualizar meta theme-color para mobile
        this.updateThemeColor(theme);
        
        // Disparar evento customizado
        this.dispatchThemeChangeEvent(theme);
    }

    updateThemeColor(theme) {
        let metaThemeColor = document.querySelector('meta[name="theme-color"]');
        if (!metaThemeColor) {
            metaThemeColor = document.createElement('meta');
            metaThemeColor.name = 'theme-color';
            document.head.appendChild(metaThemeColor);
        }
        
        metaThemeColor.content = theme === 'dark' ? '#121212' : '#2196F3';
    }

    animateToggleButton() {
        const toggleButton = document.getElementById('theme-toggle');
        if (toggleButton) {
            toggleButton.style.transform = 'scale(0.8) rotate(180deg)';
            setTimeout(() => {
                toggleButton.style.transform = 'scale(1) rotate(0deg)';
            }, 150);
        }
    }

    dispatchThemeChangeEvent(theme) {
        const event = new CustomEvent('themeChanged', { 
            detail: { theme } 
        });
        document.dispatchEvent(event);
    }

    getCurrentTheme() {
        return this.currentTheme;
    }
}

// Inicializar o gerenciador de tema quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', () => {
    window.themeManager = new ThemeManager();
});

// Para compatibilidade com carregamento assíncrono
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        if (!window.themeManager) {
            window.themeManager = new ThemeManager();
        }
    });
} else {
    window.themeManager = new ThemeManager();
}

// Utilitários extras para melhorar a experiência
document.addEventListener('themeChanged', (event) => {
    console.log(`Tema alterado para: ${event.detail.theme}`);
    
    // Aplicar transições suaves apenas após a primeira mudança
    if (!document.body.classList.contains('theme-transitions')) {
        document.body.classList.add('theme-transitions');
    }
});

// Adicionar classe para transições suaves
const style = document.createElement('style');
style.textContent = `
    .theme-transitions * {
        transition: background-color 0.3s ease, 
                    color 0.3s ease, 
                    border-color 0.3s ease,
                    box-shadow 0.3s ease !important;
    }
`;
document.head.appendChild(style);
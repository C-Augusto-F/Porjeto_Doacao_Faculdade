// notificacoes-badge.js - Atualiza o contador de notificações não lidas
document.addEventListener('DOMContentLoaded', function() {
    // Elemento do badge de notificações
    const notificacoesBadge = document.getElementById('notificacoes-badge');
    
    // Atualizar a contagem de notificações ao carregar a página
    atualizarContagemNotificacoes();
    
    // Configurar atualização periódica a cada 60 segundos
    setInterval(atualizarContagemNotificacoes, 60000);
});

// Função global para atualizar a contagem de notificações
function atualizarContagemNotificacoes() {
    const notificacoesBadge = document.getElementById('notificacoes-badge');
    if (!notificacoesBadge) return;
    
    fetch('/notificacoes/contagem', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Erro ao obter contagem de notificações');
        }
        return response.json();
    })
    .then(data => {
        // Atualizar o número no badge
        notificacoesBadge.textContent = data.nao_lidas;
        
        // Mostrar ou ocultar o badge baseado na contagem
        if (data.nao_lidas > 0) {
            notificacoesBadge.style.display = 'inline-block';
        } else {
            notificacoesBadge.style.display = 'none';
        }
    })
    .catch(error => {
        console.error('Erro ao atualizar contagem de notificações:', error);
    });
}
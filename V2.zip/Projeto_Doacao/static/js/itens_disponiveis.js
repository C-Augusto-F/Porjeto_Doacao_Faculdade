document.addEventListener('DOMContentLoaded', function() {
    const doacoesContainer = document.getElementById('doacoes-container');
    const loading = document.getElementById('loading');
    const errorMessage = document.getElementById('error-message');
    const semResultados = document.getElementById('sem-resultados');
    const paginationContainer = document.getElementById('pagination');
    const categoriaFilter = document.getElementById('categoria-filter');
    const buscaInput = document.getElementById('busca');
    const filtrarBtn = document.getElementById('filtrar-btn');
    const solicitarModal = document.getElementById('solicitar-modal');
    const modalClose = document.querySelector('.modal-close');
    const solicitarForm = document.getElementById('solicitar-form');
    const logoutBtn = document.getElementById('logout-btn');
    const dashboardToggle = document.getElementById('dashboard-toggle');
    const dashboard = document.getElementById('dashboard');
    
    // Dashboard Charts
    let categoriasChart = null;
    let statusChart = null;
    
    // Verificar se o usuário está logado
    fetch('/usuario_info')
        .then(response => {
            if (!response.ok) {
                window.location.href = '/login';
                throw new Error('Usuário não autenticado');
            }
            return response.json();
        })
        .catch(error => {
            console.error('Erro ao verificar login:', error);
            window.location.href = '/login';
        });
    
    // Configurações de paginação
    let currentPage = 1;
    const itemsPerPage = 6;
    let allDoacoes = [];
    let dashboardData = {};
    
    // Toggle Dashboard
    dashboardToggle.addEventListener('click', function() {
        const isCollapsed = dashboard.classList.contains('dashboard-collapsed');
        
        if (isCollapsed) {
            dashboard.classList.remove('dashboard-collapsed');
            dashboard.classList.add('dashboard-expanded');
            this.innerHTML = '<i class="fas fa-chevron-up"></i> Minimizar';
        } else {
            dashboard.classList.remove('dashboard-expanded');
            dashboard.classList.add('dashboard-collapsed');
            this.innerHTML = '<i class="fas fa-chevron-down"></i> Expandir';
        }
    });
    
    // Carregar dados do dashboard
    function carregarDashboard() {
        Promise.all([
            fetch('/doacoes/disponiveis').then(r => r.json()),
            fetch('/doacoes/estatisticas').then(r => r.ok ? r.json() : { 
                total_doados: 0, 
                total_solicitacoes: 0,
                categorias: [],
                status_solicitacoes: []
            })
        ])
        .then(([disponiveis, estatisticas]) => {
            dashboardData = {
                disponiveis: disponiveis,
                estatisticas: estatisticas
            };
            
            atualizarEstatisticas();
            atualizarGraficos();
        })
        .catch(error => {
            console.error('Erro ao carregar dashboard:', error);
        });
    }
    
    // Atualizar estatísticas
    function atualizarEstatisticas() {
        const disponiveis = dashboardData.disponiveis || [];
        const estatisticas = dashboardData.estatisticas || {};
        
        // Calcular estatísticas
        const totalDisponiveis = disponiveis.length;
        const totalDoados = estatisticas.total_doados || 0;
        const totalSolicitacoes = estatisticas.total_solicitacoes || 0;
        const categorias = [...new Set(disponiveis.map(d => d.categoria).filter(c => c))];
        const totalCategorias = categorias.length;
        
        // Atualizar elementos
        document.getElementById('total-disponiveis').textContent = totalDisponiveis;
        document.getElementById('total-doados').textContent = totalDoados;
        document.getElementById('total-solicitacoes').textContent = totalSolicitacoes;
        document.getElementById('total-categorias').textContent = totalCategorias;
        
        // Animar números
        animateNumbers();
    }
    
    // Animar números
    function animateNumbers() {
        const numbers = document.querySelectorAll('.stat-number');
        numbers.forEach(number => {
            const target = parseInt(number.textContent);
            if (target === 0) return;
            
            let current = 0;
            const increment = target / 30;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    number.textContent = target;
                    clearInterval(timer);
                } else {
                    number.textContent = Math.floor(current);
                }
            }, 50);
        });
    }
    
    // Atualizar gráficos
    function atualizarGraficos() {
        const disponiveis = dashboardData.disponiveis || [];
        
        // Gráfico de categorias
        atualizarGraficoCategoria(disponiveis);
        
        // Gráfico de status
        atualizarGraficoStatus();
    }
    
    // Gráfico de categorias
    function atualizarGraficoCategoria(disponiveis) {
        const ctx = document.getElementById('categorias-chart').getContext('2d');
        
        // Contar por categoria
        const categorias = {};
        disponiveis.forEach(item => {
            const cat = item.categoria || 'outros';
            categorias[cat] = (categorias[cat] || 0) + 1;
        });
        
        if (Object.keys(categorias).length === 0) {
            categorias['Nenhum item'] = 1;
        }
        
        const labels = Object.keys(categorias).map(cat => capitalizeFirstLetter(cat));
        const data = Object.values(categorias);
        const colors = [
            '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', 
            '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F'
        ];
        
        if (categoriasChart) {
            categoriasChart.destroy();
        }
        
        categoriasChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: colors.slice(0, labels.length),
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    }
    
    // Gráfico de status
    function atualizarGraficoStatus() {
        const ctx = document.getElementById('status-chart').getContext('2d');
        
        const disponiveis = dashboardData.disponiveis ? dashboardData.disponiveis.length : 0;
        const doados = dashboardData.estatisticas ? dashboardData.estatisticas.total_doados : 0;
        const solicitacoes = dashboardData.estatisticas ? dashboardData.estatisticas.total_solicitacoes : 0;
        
        if (statusChart) {
            statusChart.destroy();
        }
        
        statusChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Disponíveis', 'Total Doados', 'Solicitações'],
                datasets: [{
                    label: 'Quantidade',
                    data: [disponiveis, doados, solicitacoes],
                    backgroundColor: [
                        '#48BB78',
                        '#4299E1',
                        '#ED8936'
                    ],
                    borderColor: [
                        '#38A169',
                        '#3182CE',
                        '#DD6B20'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    }
    
    // Carregar doações disponíveis
    function carregarDoacoes() {
        loading.style.display = 'block';
        doacoesContainer.style.display = 'none';
        errorMessage.style.display = 'none';
        semResultados.style.display = 'none';
        
        fetch('/doacoes/disponiveis')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Falha ao carregar itens disponíveis');
                }
                return response.json();
            })
            .then(data => {
                allDoacoes = data;
                filtrarDoacoes();
            })
            .catch(error => {
                loading.style.display = 'none';
                errorMessage.textContent = error.message;
                errorMessage.style.display = 'block';
            });
    }
    
    // Filtrar doações
    function filtrarDoacoes() {
        const categoria = categoriaFilter.value;
        const busca = buscaInput.value.toLowerCase();
        
        let doacoesFiltradas = allDoacoes;
        
        if (categoria) {
            doacoesFiltradas = doacoesFiltradas.filter(doacao => doacao.categoria === categoria);
        }
        
        if (busca) {
            doacoesFiltradas = doacoesFiltradas.filter(doacao => 
                doacao.nome.toLowerCase().includes(busca) || 
                (doacao.descricao && doacao.descricao.toLowerCase().includes(busca))
            );
        }
        
        exibirDoacoes(doacoesFiltradas);
    }
    
    // Exibir doações com paginação
    function exibirDoacoes(doacoes) {
        loading.style.display = 'none';
        
        if (doacoes.length === 0) {
            doacoesContainer.style.display = 'none';
            paginationContainer.style.display = 'none';
            semResultados.style.display = 'block';
            return;
        }
        
        const totalPages = Math.ceil(doacoes.length / itemsPerPage);
        const start = (currentPage - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const doacoesPagina = doacoes.slice(start, end);
        
        doacoesContainer.innerHTML = '';
        
        doacoesPagina.forEach(doacao => {
            const card = document.createElement('div');
            card.className = 'doacao-card';
            
            // Função para obter ícone de categoria
            const getCategoriaIcon = (categoria) => {
                const icons = {
                    'alimentos': 'fas fa-utensils',
                    'roupas': 'fas fa-tshirt',
                    'moveis': 'fas fa-couch',
                    'eletronicos': 'fas fa-laptop',
                    'brinquedos': 'fas fa-gamepad',
                    'livros': 'fas fa-book',
                    'medicamentos': 'fas fa-pills',
                    'outros': 'fas fa-box'
                };
                return icons[categoria] || icons.outros;
            };
            
            const dataFormatada = doacao.data_doacao ? 
                formatarData(doacao.data_doacao) : 
                formatarData(new Date().toISOString());
            
            card.innerHTML = `
                <div class="doacao-header">
                    <h3>${doacao.nome}</h3>
                    <span class="categoria-badge">
                        <i class="${getCategoriaIcon(doacao.categoria)}"></i> 
                        ${capitalizeFirstLetter(doacao.categoria || 'Outros')}
                    </span>
                </div>
                <div class="doacao-body">
                    <div class="doacao-info">
                        <p><i class="fas fa-info-circle"></i> ${doacao.descricao || 'Sem descrição'}</p>
                        <p><i class="fas fa-cubes"></i> Quantidade: ${doacao.quantidade}</p>
                        <p><i class="fas fa-calendar-alt"></i> Disponível desde: ${dataFormatada}</p>
                        ${doacao.doador_nome ? `<p><i class="fas fa-user"></i> Doador: ${doacao.doador_nome}</p>` : ''}
                    </div>
                    <div class="doacao-actions">
                        <button class="solicitar-btn" data-id="${doacao.id}">Solicitar</button>
                        <button class="detalhes-btn" data-id="${doacao.id}">Ver Detalhes</button>
                    </div>
                </div>
            `;
            
            doacoesContainer.appendChild(card);
        });
        
        // Adicionar event listeners aos botões
        document.querySelectorAll('.solicitar-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                abrirModalSolicitacao(id);
            });
        });
        
        document.querySelectorAll('.detalhes-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                verDetalhesDoacao(id);
            });
        });
        
        // Configurar paginação
        configurarPaginacao(totalPages);
        
        doacoesContainer.style.display = 'grid';
        paginationContainer.style.display = 'flex';
        semResultados.style.display = 'none';
    }
    
    // Ver detalhes da doação
    function verDetalhesDoacao(id) {
        const doacao = allDoacoes.find(d => d.id == id);
        if (doacao) {
            const detalhes = `
Detalhes do item: ${doacao.nome}

Descrição: ${doacao.descricao || 'Sem descrição'}
Categoria: ${capitalizeFirstLetter(doacao.categoria || 'Outros')}
Quantidade: ${doacao.quantidade}
Data: ${formatarData(doacao.data_doacao || new Date().toISOString())}
${doacao.doador_nome ? `Doador: ${doacao.doador_nome}` : ''}
            `;
            alert(detalhes);
        }
    }
    
    // Configurar paginação
    function configurarPaginacao(totalPages) {
        paginationContainer.innerHTML = '';
        
        if (totalPages <= 1) {
            return;
        }
        
        // Botão anterior
        const prevBtn = document.createElement('button');
        prevBtn.innerHTML = '&laquo; Anterior';
        prevBtn.disabled = currentPage === 1;
        prevBtn.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                filtrarDoacoes();
            }
        });
        paginationContainer.appendChild(prevBtn);
        
        // Números de página
        const maxVisiblePages = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
        
        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }
        
        for (let i = startPage; i <= endPage; i++) {
            const pageBtn = document.createElement('button');
            pageBtn.textContent = i;
            pageBtn.className = i === currentPage ? 'active' : '';
            pageBtn.addEventListener('click', () => {
                currentPage = i;
                filtrarDoacoes();
            });
            paginationContainer.appendChild(pageBtn);
        }
        
        // Botão próximo
        const nextBtn = document.createElement('button');
        nextBtn.innerHTML = 'Próximo &raquo;';
        nextBtn.disabled = currentPage === totalPages;
        nextBtn.addEventListener('click', () => {
            if (currentPage < totalPages) {
                currentPage++;
                filtrarDoacoes();
            }
        });
        paginationContainer.appendChild(nextBtn);
    }
    
    // Abrir modal para solicitar doação
    function abrirModalSolicitacao(id) {
        const doacao = allDoacoes.find(d => d.id == id);
        
        if (!doacao) return;
        
        document.getElementById('doacao-id').value = doacao.id;
        document.getElementById('item-nome').value = doacao.nome;
        document.getElementById('item-descricao').value = doacao.descricao || '';
        document.getElementById('item-quantidade').value = doacao.quantidade;
        document.getElementById('quantidade-solicitada').max = doacao.quantidade;
        document.getElementById('quantidade-solicitada').value = 1;
        document.getElementById('motivo').value = '';
        
        solicitarModal.style.display = 'flex';
    }
    
    // Fechar modal
    modalClose.addEventListener('click', () => {
        solicitarModal.style.display = 'none';
    });
    
    // Clicar fora do modal para fechar
    window.addEventListener('click', (e) => {
        if (e.target === solicitarModal) {
            solicitarModal.style.display = 'none';
        }
    });
    
    // Submeter formulário de solicitação
    solicitarForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const doacaoId = document.getElementById('doacao-id').value;
        const quantidadeSolicitada = parseInt(document.getElementById('quantidade-solicitada').value);
        const motivo = document.getElementById('motivo').value;
        
        // Validações básicas
        if (!doacaoId || !quantidadeSolicitada || !motivo.trim()) {
            alert('Por favor, preencha todos os campos obrigatórios.');
            return;
        }
        
        const doacao = allDoacoes.find(d => d.id == doacaoId);
        if (quantidadeSolicitada > doacao.quantidade) {
            alert('Quantidade solicitada não pode ser maior que a disponível.');
            return;
        }
        
        // Desabilitar botão durante o envio
        const submitBtn = solicitarForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
        
        // Enviar a solicitação ao backend
        fetch('/solicitacoes/criar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                doacao_id: parseInt(doacaoId),
                quantidade: quantidadeSolicitada,
                motivo: motivo.trim()
            })
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(err => {
                    throw new Error(err.error || 'Falha ao enviar solicitação');
                });
            }
            return response.json();
        })
        .then(data => {
            alert('Solicitação enviada com sucesso!');
            solicitarModal.style.display = 'none';
            carregarDoacoes(); // Recarregar a lista
            carregarDashboard(); // Atualizar dashboard
        })
        .catch(error => {
            console.error('Erro ao enviar solicitação:', error);
            alert('Erro ao enviar solicitação: ' + error.message);
        })
        .finally(() => {
            // Reabilitar botão
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        });
    });
    
    // Event listener para o botão de filtrar
    filtrarBtn.addEventListener('click', function() {
        currentPage = 1;
        filtrarDoacoes();
    });
    
    // Event listener para pesquisa ao pressionar Enter
    buscaInput.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            currentPage = 1;
            filtrarDoacoes();
        }
    });
    
    // Event listener para mudança de categoria
    categoriaFilter.addEventListener('change', function() {
        currentPage = 1;
        filtrarDoacoes();
    });
    
    // Logout
    logoutBtn.addEventListener('click', function(e) {
        e.preventDefault();
        
        if (confirm('Tem certeza que deseja sair?')) {
            fetch('/logout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Falha ao fazer logout');
                }
                return response.json();
            })
            .then(data => {
                window.location.href = '/login';
            })
            .catch(error => {
                console.error('Erro no logout:', error);
                // Mesmo com erro, redirecionar para login
                window.location.href = '/login';
            });
        }
    });
    
    // Funções utilitárias
    function formatarData(dataString) {
        try {
            const data = new Date(dataString);
            return data.toLocaleDateString('pt-BR', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        } catch (error) {
            return 'Data não disponível';
        }
    }
    
    function capitalizeFirstLetter(string) {
        if (!string) return '';
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    
    // Inicializar aplicação
    function inicializar() {
        carregarDashboard();
        carregarDoacoes();
        
        // Atualizar dados a cada 30 segundos
        setInterval(() => {
            carregarDashboard();
        }, 30000);
    }
    
    // Iniciar quando a página carregar
    inicializar();
});
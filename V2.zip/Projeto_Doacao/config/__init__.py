# ==================== config/__init__.py ====================
"""
Módulo de configuração do sistema de doações
Contém configurações de banco de dados e outras configurações globais
"""

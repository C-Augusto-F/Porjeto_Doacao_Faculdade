import mysql.connector
from contextlib import contextmanager

def conectar_banco():
    return mysql.connector.connect(
        host="127.0.0.1",
        user="root",
        password="M@h0r4g4",
        database="projeto_doacao"
    )

@contextmanager
def get_db_connection():
    """Context manager para conexões de banco"""
    conexao = None
    cursor = None
    try:
        conexao = conectar_banco()
        cursor = conexao.cursor(dictionary=True)
        yield conexao, cursor
    except Exception as e:
        if conexao:
            conexao.rollback()
        raise e
    finally:
        if cursor:
            cursor.close()
        if conexao:
            conexao.close()
# ==================== utils/__init__.py ====================
"""
Módulo de utilitários do sistema de doações
Contém decorators, helpers e outras funções auxiliares
"""

from .decorators import login_required

__all__ = ['login_required']
from flask import Flask, render_template, request, jsonify, session, send_from_directory
import mysql.connector
from flask_cors import CORS
import secrets
import os
from functools import wraps
from datetime import datetime

app = Flask(__name__, static_folder='static', template_folder='templates')
# Define uma chave secreta fixa para produção ou use variável de ambiente
# app.secret_key = os.environ.get('SECRET_KEY', 'chave_secreta_fixa_para_desenvolvimento')
app.secret_key = secrets.token_hex(16)  # Mantido para desenvolvimento, mas deverá ser fixo em produção

# Configuração CORS
CORS(app, resources={
    r"/*": {
        "origins": ["http://localhost:5000"],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"],
        "supports_credentials": True
    }
})

def conectar_banco():
    return mysql.connector.connect(
        host="127.0.0.1",
        user="root",
        password="M@h0r4g4",
        database="projeto_doacao"
    )

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario_id' not in session:
            return jsonify({'error': 'Acesso não autorizado'}), 401
        return f(*args, **kwargs)
    return decorated_function

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(app.static_folder, filename)

@app.route('/js/<path:filename>')
def js_files(filename):
    return send_from_directory(os.path.join(app.static_folder, 'js'), filename)

@app.after_request
def add_no_cache_headers(response):
    if request.endpoint != 'static':
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
    return response

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'Dados inválidos'}), 400

            email = data.get('email')
            senha = data.get('password')

            conexao = conectar_banco()
            cursor = conexao.cursor(dictionary=True)
            
            # Modificado para verificar senha diretamente - sem hash
            # TODO: Implementar hash de senha para segurança
            cursor.execute(
                "SELECT id, nome FROM usuarios WHERE email = %s AND senha = %s",
                (email, senha)
            )
            usuario = cursor.fetchone()

            if usuario:
                session['usuario_id'] = usuario['id']
                session['usuario_nome'] = usuario['nome']
                return jsonify({
                    'message': 'Login realizado com sucesso',
                    'user': {'id': usuario['id'], 'nome': usuario['nome']}
                }), 200
            else:
                return jsonify({'error': 'Credenciais inválidas'}), 401

        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conexao' in locals():
                conexao.close()

    return render_template('login.html')

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'Dados inválidos'}), 400

            nome = data.get('name')
            email = data.get('email')
            senha = data.get('password')

            if not all([nome, email, senha]):
                return jsonify({'error': 'Todos os campos são obrigatórios'}), 400

            conexao = conectar_banco()
            cursor = conexao.cursor()

            cursor.execute("SELECT id FROM usuarios WHERE email = %s", (email,))
            if cursor.fetchone():
                return jsonify({'error': 'Email já cadastrado'}), 400

            # TODO: Implementar hash de senha para segurança
            cursor.execute(
                "INSERT INTO usuarios (nome, email, senha, tipo) VALUES (%s, %s, %s, 'doador')",
                (nome, email, senha)
            )
            conexao.commit()

            return jsonify({'message': 'Cadastro realizado com sucesso'}), 201

        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conexao' in locals():
                conexao.close()

    return render_template('cadastro.html')

# Nova rota para doacoes_page
@app.route('/doacoes_page')
@login_required
def doacoes_page():
    return render_template('doacoes.html')

# Adicionar rota para usuário_info
@app.route('/usuario_info', methods=['GET'])
@login_required
def usuario_info():
    return jsonify({
        'id': session.get('usuario_id'),
        'nome': session.get('usuario_nome')
    })

@app.route('/doacoes', methods=['GET', 'POST'])
@login_required
def doacoes():
    if request.method == 'GET':
        try:
            conexao = conectar_banco()
            cursor = conexao.cursor(dictionary=True)
            cursor.execute(
                "SELECT id, nome, descricao, categoria, quantidade, DATE_FORMAT(data_doacao, '%Y-%m-%d') as data_doacao FROM doacoes WHERE usuario_id = %s", 
                (session['usuario_id'],)
            )
            doacoes = cursor.fetchall()
            return jsonify(doacoes), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()
    elif request.method == 'POST':
        try:
            data = request.get_json()
            nome = data.get('nome')
            quantidade = data.get('quantidade')
            descricao = data.get('descricao', '')
            categoria = data.get('categoria', 'outros')

            if not nome or not quantidade:
                return jsonify({'error': 'Nome e quantidade são obrigatórios'}), 400

            conexao = conectar_banco()
            cursor = conexao.cursor()
            cursor.execute(
                "INSERT INTO doacoes (nome, descricao, categoria, quantidade, usuario_id) VALUES (%s, %s, %s, %s, %s)",
                (nome, descricao, categoria, quantidade, session['usuario_id'])
            )
            conexao.commit()
            return jsonify({'message': 'Doação registrada com sucesso'}), 201
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()
    else:
        return render_template('doacoes.html')

@app.route('/doacoes/<int:id>', methods=['PUT', 'DELETE'])
@login_required
def gerenciar_doacao(id):
    if request.method == 'PUT':
        try:
            data = request.get_json()
            nome = data.get('nome')
            quantidade = data.get('quantidade')
            descricao = data.get('descricao', '')
            categoria = data.get('categoria', 'outros')

            conexao = conectar_banco()
            cursor = conexao.cursor()
            cursor.execute(
                "UPDATE doacoes SET nome=%s, quantidade=%s, descricao=%s, categoria=%s WHERE id=%s AND usuario_id=%s",
                (nome, quantidade, descricao, categoria, id, session['usuario_id'])
            )
            conexao.commit()
            return jsonify({'message': 'Doação atualizada com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()
    elif request.method == 'DELETE':
        try:
            conexao = conectar_banco()
            cursor = conexao.cursor()
            cursor.execute("DELETE FROM doacoes WHERE id=%s AND usuario_id=%s", (id, session['usuario_id']))
            conexao.commit()
            return jsonify({'message': 'Doação excluída com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()

# Adicionar rotas para solicitações
@app.route('/solicitacoes', methods=['GET', 'POST'])
@login_required
def solicitacoes():
    if request.method == 'GET':
        try:
            conexao = conectar_banco()
            cursor = conexao.cursor(dictionary=True)
            cursor.execute(
                "SELECT id, nome, descricao, categoria, quantidade, status, DATE_FORMAT(data_solicitacao, '%Y-%m-%d') as data_solicitacao FROM solicitacoes WHERE usuario_id = %s", 
                (session['usuario_id'],)
            )
            solicitacoes = cursor.fetchall()
            return jsonify(solicitacoes), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()
    elif request.method == 'POST':
        try:
            data = request.get_json()
            nome = data.get('nome')
            quantidade = data.get('quantidade')
            descricao = data.get('descricao', '')
            categoria = data.get('categoria', 'outros')

            if not nome or not quantidade:
                return jsonify({'error': 'Nome e quantidade são obrigatórios'}), 400

            conexao = conectar_banco()
            cursor = conexao.cursor()
            cursor.execute(
                "INSERT INTO solicitacoes (nome, descricao, categoria, quantidade, usuario_id, status) VALUES (%s, %s, %s, %s, %s, 'pendente')",
                (nome, descricao, categoria, quantidade, session['usuario_id'])
            )
            conexao.commit()
            return jsonify({'message': 'Solicitação registrada com sucesso'}), 201
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()

@app.route('/solicitacoes/<int:id>', methods=['PUT', 'DELETE'])
@login_required
def gerenciar_solicitacao(id):
    if request.method == 'PUT':
        try:
            data = request.get_json()
            nome = data.get('nome')
            quantidade = data.get('quantidade')
            descricao = data.get('descricao', '')
            categoria = data.get('categoria', 'outros')
            status = data.get('status', 'pendente')

            conexao = conectar_banco()
            cursor = conexao.cursor()
            cursor.execute(
                "UPDATE solicitacoes SET nome=%s, quantidade=%s, descricao=%s, categoria=%s, status=%s WHERE id=%s AND usuario_id=%s",
                (nome, quantidade, descricao, categoria, status, id, session['usuario_id'])
            )
            conexao.commit()
            return jsonify({'message': 'Solicitação atualizada com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()
    elif request.method == 'DELETE':
        try:
            conexao = conectar_banco()
            cursor = conexao.cursor()
            cursor.execute("DELETE FROM solicitacoes WHERE id=%s AND usuario_id=%s", (id, session['usuario_id']))
            conexao.commit()
            return jsonify({'message': 'Solicitação excluída com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()

@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logout realizado com sucesso'})

# Solicitações page
@app.route('/solicitacoes_page')
@login_required
def solicitacoes_page():
    return render_template('solicitacoes.html')

#@app.route('/itens_disponiveis')
#@login_required
#def itens_disponiveis():
#    return render_template('itens_disponiveis.html')
@app.route('/itens_disponiveis')
@login_required
def itens_disponiveis():
    return render_template('itens_disponiveis.html')

# Rota para buscar doações disponíveis
@app.route('/doacoes/disponiveis')
@login_required
def doacoes_disponiveis():
    try:
        conn = conectar_banco()
        cursor = conn.cursor(dictionary=True)
        
        # Buscar produtos do tipo 'doacao' que ainda não foram totalmente solicitados
        query = """
        SELECT p.*, u.nome as doador_nome 
        FROM produtos p 
        JOIN usuarios u ON p.usuario_id = u.id 
        WHERE p.tipo = 'doacao' AND p.quantidade > 0
        ORDER BY p.data_registro DESC
        """
        
        cursor.execute(query)
        doacoes = cursor.fetchall()
        
        # Converter datas para string para JSON
        for doacao in doacoes:
            if doacao['data_registro']:
                doacao['data_doacao'] = doacao['data_registro'].strftime('%Y-%m-%d %H:%M:%S')
            else:
                doacao['data_doacao'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        cursor.close()
        conn.close()
        
        return jsonify(doacoes)
        
    except Exception as e:
        print(f"Erro ao buscar doações: {e}")
        return jsonify({"error": "Erro interno do servidor"}), 500

# Rota para estatísticas do dashboard
@app.route('/doacoes/estatisticas')
@login_required
def doacoes_estatisticas():
    try:
        conn = conectar_banco()
        cursor = conn.cursor(dictionary=True)
        
        # Contar total de produtos doados (quantidade total de doações)
        cursor.execute("SELECT COALESCE(SUM(quantidade), 0) as total FROM produtos WHERE tipo = 'doacao'")
        total_doados = cursor.fetchone()['total']
        
        # Contar total de solicitações pendentes
        cursor.execute("SELECT COUNT(*) as total FROM solicitacoes WHERE status = 'pendente'")
        total_solicitacoes = cursor.fetchone()['total']
        
        # Estatísticas por categoria (doações)
        cursor.execute("""
            SELECT categoria, COUNT(*) as total, SUM(quantidade) as quantidade_total 
            FROM produtos 
            WHERE tipo = 'doacao' 
            GROUP BY categoria
        """)
        estatisticas_categorias = cursor.fetchall()
        
        # Estatísticas por status das solicitações
        cursor.execute("""
            SELECT status, COUNT(*) as total 
            FROM solicitacoes 
            GROUP BY status
        """)
        estatisticas_status = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            "total_doados": total_doados,
            "total_solicitacoes": total_solicitacoes,
            "categorias": estatisticas_categorias,
            "status_solicitacoes": estatisticas_status
        })
        
    except Exception as e:
        print(f"Erro ao buscar estatísticas: {e}")
        return jsonify({"error": "Erro interno do servidor"}), 500


@app.route('/doacoes/disponiveis')
@login_required
def listar_doacoes_disponiveis():
    try:
        conexao = conectar_banco()
        cursor = conexao.cursor(dictionary=True)
        
        # Seleciona todas as doações exceto as do usuário atual
        cursor.execute(
            """
            SELECT d.id, d.nome, d.descricao, d.categoria, d.quantidade, 
                   DATE_FORMAT(d.data_doacao, '%Y-%m-%d') as data_doacao,
                   u.nome as doador
            FROM doacoes d
            JOIN usuarios u ON d.usuario_id = u.id
            WHERE d.usuario_id != %s AND d.quantidade > 0
            ORDER BY d.data_doacao DESC
            """, 
            (session['usuario_id'],)
        )
        
        doacoes = cursor.fetchall()
        return jsonify(doacoes), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        if 'cursor' in locals(): cursor.close()
        if 'conexao' in locals(): conexao.close()

@app.route('/solicitacoes/criar', methods=['POST'])
@login_required
def criar_solicitacao():
    try:
        data = request.get_json()
        doacao_id = data.get('doacao_id')
        quantidade = int(data.get('quantidade'))
        motivo = data.get('motivo', '')

        if not doacao_id or not quantidade:
            return jsonify({'error': 'Doação ID e quantidade são obrigatórios'}), 400

        conexao = conectar_banco()
        cursor = conexao.cursor(dictionary=True)
        
        try:
            # Iniciar transação
            conexao.start_transaction()
            
            # Verificar se a doação existe e tem quantidade suficiente
            cursor.execute(
                "SELECT id, nome, quantidade, usuario_id FROM doacoes WHERE id = %s", 
                (doacao_id,)
            )
            
            doacao = cursor.fetchone()
            
            if not doacao:
                return jsonify({'error': 'Doação não encontrada'}), 404
                
            if doacao['usuario_id'] == session['usuario_id']:
                return jsonify({'error': 'Você não pode solicitar sua própria doação'}), 400
                
            if doacao['quantidade'] < quantidade:
                return jsonify({'error': 'Quantidade solicitada maior que a disponível'}), 400
            
            # Criar a solicitação
            cursor.execute(
                """
                INSERT INTO solicitacoes 
                (usuario_id, nome, descricao, categoria, quantidade, status, doacao_id) 
                SELECT %s, d.nome, %s, d.categoria, %s, 'pendente', d.id
                FROM doacoes d WHERE d.id = %s
                """,
                (session['usuario_id'], motivo, quantidade, doacao_id)
            )
            
            solicitacao_id = cursor.lastrowid
            
            # Buscar nome do usuário solicitante
            cursor.execute("SELECT nome FROM usuarios WHERE id = %s", (session['usuario_id'],))
            usuario = cursor.fetchone()
            
            # Criar notificação para o doador
            cursor.execute(
                """
                INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
                VALUES (%s, %s, %s, 'solicitacao')
                """,
                (
                    doacao['usuario_id'], 
                    "Nova Solicitação de Doação", 
                    f"{usuario['nome']} solicitou {quantidade} unidade(s) do item '{doacao['nome']}' que você disponibilizou para doação."
                )
            )
            
            # Criar notificação para o solicitante
            cursor.execute(
                """
                INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
                VALUES (%s, %s, %s, 'solicitacao_enviada')
                """,
                (
                    session['usuario_id'], 
                    "Solicitação Enviada", 
                    f"Sua solicitação para o item '{doacao['nome']}' foi enviada com sucesso. Aguarde a resposta do doador."
                )
            )
            
            # Confirmar transação
            conexao.commit()
            
            return jsonify({
                'message': 'Solicitação criada com sucesso',
                'solicitacao_id': solicitacao_id
            }), 201
            
        except Exception as e:
            # Em caso de erro, fazer rollback
            conexao.rollback()
            raise e
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        if 'cursor' in locals(): cursor.close()
        if 'conexao' in locals(): conexao.close()

@app.route('/campanhas_page')
@login_required
def campanhas_page():
    return render_template('campanhas.html')

@app.route('/campanhas', methods=['GET'])
@login_required
def listar_campanhas():
    try:
        conexao = conectar_banco()
        cursor = conexao.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT id, nome, descricao, DATE_FORMAT(data_inicio, '%Y-%m-%d') as data_inicio, 
                   DATE_FORMAT(data_fim, '%Y-%m-%d') as data_fim, 
                   meta_financeira, valor_arrecadado, status
            FROM campanhas 
            WHERE status = 'ativa'
            ORDER BY data_inicio DESC
        """)
        
        campanhas = cursor.fetchall()
        return jsonify(campanhas), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        if 'cursor' in locals(): cursor.close()
        if 'conexao' in locals(): conexao.close()

@app.route('/campanhas/<int:id>/contribuir', methods=['POST'])
@login_required
def contribuir_campanha(id):
    try:
        data = request.get_json()
        valor = float(data.get('valor', 0))
        
        if valor <= 0:
            return jsonify({'error': 'Valor deve ser maior que zero'}), 400
            
        conexao = conectar_banco()
        cursor = conexao.cursor(dictionary=True)
        
        try:
            # Iniciar transação
            conexao.start_transaction()
            
            # Verificar se a campanha existe e está ativa
            cursor.execute(
                "SELECT id, nome, status FROM campanhas WHERE id = %s", 
                (id,)
            )
            
            campanha = cursor.fetchone()
            
            if not campanha:
                return jsonify({'error': 'Campanha não encontrada'}), 404
                
            if campanha['status'] != 'ativa':
                return jsonify({'error': 'Esta campanha não está mais ativa'}), 400
            
            # Atualizar valor arrecadado
            cursor.execute(
                "UPDATE campanhas SET valor_arrecadado = valor_arrecadado + %s WHERE id = %s",
                (valor, id)
            )
            
            # Registrar a contribuição na tabela de contribuições
            cursor.execute(
                """
                INSERT INTO contribuicoes (usuario_id, campanha_id, valor, data_contribuicao)
                VALUES (%s, %s, %s, NOW())
                """,
                (session['usuario_id'], id, valor)
            )
            
            contribuicao_id = cursor.lastrowid
            
            # Criar notificação para o usuário
            cursor.execute(
                """
                INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
                VALUES (%s, %s, %s, 'contribuicao')
                """,
                (
                    session['usuario_id'], 
                    "Contribuição Realizada", 
                    f"Sua contribuição de R$ {valor:.2f} para a campanha '{campanha['nome']}' foi registrada com sucesso!"
                )
            )
            
            # Confirmar transação
            conexao.commit()
            
            return jsonify({
                'message': 'Contribuição realizada com sucesso',
                'contribuicao_id': contribuicao_id
            }), 201
            
        except Exception as e:
            # Em caso de erro, fazer rollback
            conexao.rollback()
            raise e
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        if 'cursor' in locals(): cursor.close()
        if 'conexao' in locals(): conexao.close()

@app.route('/notificacoes_page')
@login_required
def notificacoes_page():
    return render_template('notificacoes.html')

@app.route('/notificacoes', methods=['GET'])
@login_required
def listar_notificacoes():
    try:
        conexao = conectar_banco()
        cursor = conexao.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT id, titulo, mensagem, tipo, lida, 
                   DATE_FORMAT(data_envio, '%d/%m/%Y %H:%i') as data_criacao
            FROM notificacoes 
            WHERE usuario_id = %s
            ORDER BY data_envio DESC, lida ASC
        """, (session['usuario_id'],))
        
        notificacoes = cursor.fetchall()
        
        # Conta notificações não lidas
        cursor.execute(
            "SELECT COUNT(*) as nao_lidas FROM notificacoes WHERE usuario_id = %s AND lida = 0", 
            (session['usuario_id'],)
        )
        
        contagem = cursor.fetchone()
        
        return jsonify({
            'notificacoes': notificacoes,
            'nao_lidas': contagem['nao_lidas'] if contagem else 0
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        if 'cursor' in locals(): cursor.close()
        if 'conexao' in locals(): conexao.close()

@app.route('/notificacoes/marcar_lida/<int:id>', methods=['PUT'])
@login_required
def marcar_notificacao_lida(id):
    try:
        conexao = conectar_banco()
        cursor = conexao.cursor()
        
        cursor.execute(
            "UPDATE notificacoes SET lida = 1 WHERE id = %s AND usuario_id = %s",
            (id, session['usuario_id'])
        )
        
        conexao.commit()
        
        return jsonify({'message': 'Notificação marcada como lida'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        if 'cursor' in locals(): cursor.close()
        if 'conexao' in locals(): conexao.close()

@app.route('/notificacoes/contagem', methods=['GET'])
@login_required
def contagem_notificacoes():
    try:
        conexao = conectar_banco()
        cursor = conexao.cursor(dictionary=True)
        
        cursor.execute(
            "SELECT COUNT(*) as nao_lidas FROM notificacoes WHERE usuario_id = %s AND lida = 0", 
            (session['usuario_id'],)
        )
        
        contagem = cursor.fetchone()
        
        return jsonify({
            'nao_lidas': contagem['nao_lidas'] if contagem else 0
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        if 'cursor' in locals(): cursor.close()
        if 'conexao' in locals(): conexao.close()

#rotas campanhas#


@app.route('/campanhas', methods=['GET', 'POST'])
@login_required
def campanhas():
    if request.method == 'GET':
        try:
            conexao = conectar_banco()
            cursor = conexao.cursor(dictionary=True)
            cursor.execute("SELECT * FROM campanhas")
            campanhas = cursor.fetchall()
            return jsonify(campanhas), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()
    elif request.method == 'POST':
        try:
            data = request.get_json()
            nome = data.get('nome')
            descricao = data.get('descricao')
            data_inicio = data.get('data_inicio')
            data_fim = data.get('data_fim')
            meta_financeira = data.get('meta_financeira')

            if not all([nome, descricao, data_inicio, data_fim, meta_financeira]):
                return jsonify({'error': 'Todos os campos são obrigatórios'}), 400

            conexao = conectar_banco()
            cursor = conexao.cursor()
            cursor.execute(
                "INSERT INTO campanhas (nome, descricao, data_inicio, data_fim, meta_financeira) VALUES (%s, %s, %s, %s, %s)",
                (nome, descricao, data_inicio, data_fim, meta_financeira)
            )
            conexao.commit()
            return jsonify({'message': 'Campanha criada com sucesso'}), 201
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()

@app.route('/campanhas/<int:id>', methods=['PUT', 'DELETE'])
@login_required
def gerenciar_campanha(id):
    if request.method == 'PUT':
        try:
            data = request.get_json()
            nome = data.get('nome')
            descricao = data.get('descricao')
            data_inicio = data.get('data_inicio')
            data_fim = data.get('data_fim')
            meta_financeira = data.get('meta_financeira')
            status = data.get('status')

            if not all([nome, descricao, data_inicio, data_fim, meta_financeira, status]):
                return jsonify({'error': 'Todos os campos são obrigatórios'}), 400

            conexao = conectar_banco()
            cursor = conexao.cursor()
            cursor.execute(
                "UPDATE campanhas SET nome=%s, descricao=%s, data_inicio=%s, data_fim=%s, meta_financeira=%s, status=%s WHERE id=%s",
                (nome, descricao, data_inicio, data_fim, meta_financeira, status, id)
            )
            conexao.commit()
            return jsonify({'message': 'Campanha atualizada com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()
    elif request.method == 'DELETE':
        try:
            conexao = conectar_banco()
            cursor = conexao.cursor()
            cursor.execute("DELETE FROM campanhas WHERE id=%s", (id,))
            conexao.commit()
            return jsonify({'message': 'Campanha excluída com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conexao' in locals(): conexao.close()
# Rota da página principal de campanhas

@app.route('/campanhas', methods=['POST'])
@login_required
def criar_campanha():
    try:
        data = request.get_json()

        nome = data.get('nome')
        descricao = data.get('descricao')
        data_inicio = data.get('data_inicio')
        data_fim = data.get('data_fim')
        meta_financeira = float(data.get('meta_financeira', 0))

        # Verificação básica
        if not all([nome, descricao, data_inicio, data_fim, meta_financeira]):
            return jsonify({'error': 'Todos os campos são obrigatórios'}), 400

        # Conexão e inserção
        conexao = conectar_banco()
        cursor = conexao.cursor()

        cursor.execute("""
            INSERT INTO campanhas (nome, descricao, data_inicio, data_fim, meta_financeira)
            VALUES (%s, %s, %s, %s, %s)
        """, (nome, descricao, data_inicio, data_fim, meta_financeira))

        conexao.commit()
        return jsonify({'message': 'Campanha criada com sucesso!'}), 201

    except Exception as e:
        return jsonify({'error': str(e)}), 500

    finally:
        if 'cursor' in locals(): cursor.close()
        if 'conexao' in locals(): conexao.close()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
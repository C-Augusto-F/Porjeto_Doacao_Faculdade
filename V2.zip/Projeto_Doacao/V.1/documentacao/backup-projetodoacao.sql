-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: projeto_doacao
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `atividades`
--

DROP TABLE IF EXISTS `atividades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `atividades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text,
  `local` varchar(100) NOT NULL,
  `data_hora` datetime NOT NULL,
  `duracao_horas` decimal(4,1) NOT NULL,
  `vagas_total` int NOT NULL DEFAULT '1',
  `vagas_preenchidas` int NOT NULL DEFAULT '0',
  `campanha_id` int DEFAULT NULL,
  `status` enum('agendada','concluida','cancelada') DEFAULT 'agendada',
  PRIMARY KEY (`id`),
  KEY `campanha_id` (`campanha_id`),
  CONSTRAINT `atividades_ibfk_1` FOREIGN KEY (`campanha_id`) REFERENCES `campanhas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atividades`
--

LOCK TABLES `atividades` WRITE;
/*!40000 ALTER TABLE `atividades` DISABLE KEYS */;
/*!40000 ALTER TABLE `atividades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campanhas`
--

DROP TABLE IF EXISTS `campanhas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campanhas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text,
  `data_inicio` date NOT NULL,
  `data_fim` date NOT NULL,
  `meta_financeira` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_arrecadado` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` enum('ativa','encerrada','cancelada') DEFAULT 'ativa',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campanhas`
--

LOCK TABLES `campanhas` WRITE;
/*!40000 ALTER TABLE `campanhas` DISABLE KEYS */;
INSERT INTO `campanhas` VALUES (2,'Natal Solidário','Distribuição de brinquedos e cestas básicas para famílias carentes.','2024-11-01','2024-12-25',8000.00,8500.00,'encerrada'),(3,'SOS Enchentes RS','Ajuda emergencial às vítimas das enchentes no Rio Grande do Sul.','2025-03-01','2025-05-15',10000.00,6624.00,'ativa'),(4,'Páscoa Feliz','Doação de chocolates e kits escolares para crianças.','2024-03-01','2024-03-31',3000.00,3050.00,'encerrada'),(5,'Campanha de Saúde Rural','Atendimentos médicos gratuitos em comunidades rurais.','2025-07-01','2025-09-30',15000.00,5111.00,'ativa'),(6,'Ajuda aos Animais Resgatados','Tratamento e adoção de animais vítimas de maus-tratos.','2024-08-01','2024-10-15',7000.00,7100.00,'encerrada'),(8,'Apoio a Famílias Desempregadas','Ajuda financeira temporária para famílias em vulnerabilidade.','2025-02-01','2025-08-01',20000.00,10000.00,'cancelada'),(10,'livro','rge','2025-04-25','2025-04-29',525.00,525.00,'ativa'),(12,'livros','campanahs livro para esola','2025-04-17','2025-05-08',10000.00,9999.00,'ativa');
/*!40000 ALTER TABLE `campanhas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contribuicoes`
--

DROP TABLE IF EXISTS `contribuicoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contribuicoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `campanha_id` int NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `data_contribuicao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `campanha_id` (`campanha_id`),
  CONSTRAINT `contribuicoes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `contribuicoes_ibfk_2` FOREIGN KEY (`campanha_id`) REFERENCES `campanhas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contribuicoes`
--

LOCK TABLES `contribuicoes` WRITE;
/*!40000 ALTER TABLE `contribuicoes` DISABLE KEYS */;
INSERT INTO `contribuicoes` VALUES (1,6,3,1.00,'2025-04-22 23:52:29'),(2,6,3,100.00,'2025-04-22 23:52:44'),(3,6,3,123.00,'2025-04-22 23:56:05'),(4,6,5,1111.00,'2025-04-23 01:46:58'),(5,6,10,525.00,'2025-04-23 02:26:18'),(6,6,12,9999.00,'2025-04-23 22:31:25');
/*!40000 ALTER TABLE `contribuicoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doacoes`
--

DROP TABLE IF EXISTS `doacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doacoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text,
  `categoria` varchar(50) DEFAULT NULL,
  `quantidade` int NOT NULL DEFAULT '1',
  `usuario_id` int NOT NULL,
  `data_doacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `doacoes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doacoes`
--

LOCK TABLES `doacoes` WRITE;
/*!40000 ALTER TABLE `doacoes` DISABLE KEYS */;
INSERT INTO `doacoes` VALUES (1,'arroz','','alimentos',1,5,'2025-04-19 20:24:31'),(3,'Dinheiro','','outros',1,6,'2025-04-19 20:29:59'),(4,'arroz','','alimentos',1,7,'2025-04-20 00:03:11');
/*!40000 ALTER TABLE `doacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doacoes_financeiras`
--

DROP TABLE IF EXISTS `doacoes_financeiras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doacoes_financeiras` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `campanha_id` int DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL,
  `forma_pagamento` varchar(50) DEFAULT NULL,
  `status` enum('pendente','confirmada','cancelada') DEFAULT 'pendente',
  `anonima` tinyint(1) DEFAULT '0',
  `data_doacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `campanha_id` (`campanha_id`),
  CONSTRAINT `doacoes_financeiras_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `doacoes_financeiras_ibfk_2` FOREIGN KEY (`campanha_id`) REFERENCES `campanhas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doacoes_financeiras`
--

LOCK TABLES `doacoes_financeiras` WRITE;
/*!40000 ALTER TABLE `doacoes_financeiras` DISABLE KEYS */;
/*!40000 ALTER TABLE `doacoes_financeiras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evento_participantes`
--

DROP TABLE IF EXISTS `evento_participantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evento_participantes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `evento_id` int NOT NULL,
  `usuario_id` int NOT NULL,
  `confirmado` tinyint(1) DEFAULT '0',
  `data_inscricao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `evento_id` (`evento_id`,`usuario_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `evento_participantes_ibfk_1` FOREIGN KEY (`evento_id`) REFERENCES `eventos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `evento_participantes_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evento_participantes`
--

LOCK TABLES `evento_participantes` WRITE;
/*!40000 ALTER TABLE `evento_participantes` DISABLE KEYS */;
/*!40000 ALTER TABLE `evento_participantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eventos`
--

DROP TABLE IF EXISTS `eventos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eventos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `descricao` text,
  `data_evento` datetime NOT NULL,
  `local` varchar(255) DEFAULT NULL,
  `criador_id` int NOT NULL,
  `data_criacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `publicado` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `criador_id` (`criador_id`),
  CONSTRAINT `eventos_ibfk_1` FOREIGN KEY (`criador_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventos`
--

LOCK TABLES `eventos` WRITE;
/*!40000 ALTER TABLE `eventos` DISABLE KEYS */;
/*!40000 ALTER TABLE `eventos` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `after_evento_insert` AFTER INSERT ON `eventos` FOR EACH ROW BEGIN
    INSERT INTO notificacoes (usuario_id, tipo, mensagem, referencia_id)
    VALUES (NEW.criador_id, 'evento', 
    CONCAT('Evento agendado: ', NEW.titulo, ' em ', DATE_FORMAT(NEW.data_evento, '%d/%m/%Y')), 
    NEW.id);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `impacto_doacoes`
--

DROP TABLE IF EXISTS `impacto_doacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `impacto_doacoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campanha_id` int NOT NULL,
  `descricao` text NOT NULL,
  `pessoas_beneficiadas` int NOT NULL DEFAULT '0',
  `recursos_utilizados` text,
  `data_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `campanha_id` (`campanha_id`),
  CONSTRAINT `impacto_doacoes_ibfk_1` FOREIGN KEY (`campanha_id`) REFERENCES `campanhas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impacto_doacoes`
--

LOCK TABLES `impacto_doacoes` WRITE;
/*!40000 ALTER TABLE `impacto_doacoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `impacto_doacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscricoes_voluntarios`
--

DROP TABLE IF EXISTS `inscricoes_voluntarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscricoes_voluntarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `atividade_id` int NOT NULL,
  `status` enum('confirmada','pendente','cancelada') DEFAULT 'pendente',
  `data_inscricao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario_id` (`usuario_id`,`atividade_id`),
  KEY `atividade_id` (`atividade_id`),
  CONSTRAINT `inscricoes_voluntarios_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `inscricoes_voluntarios_ibfk_2` FOREIGN KEY (`atividade_id`) REFERENCES `atividades` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscricoes_voluntarios`
--

LOCK TABLES `inscricoes_voluntarios` WRITE;
/*!40000 ALTER TABLE `inscricoes_voluntarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `inscricoes_voluntarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_atividades`
--

DROP TABLE IF EXISTS `log_atividades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_atividades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `acao` varchar(100) NOT NULL,
  `descricao` text,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `data_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `log_atividades_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_atividades`
--

LOCK TABLES `log_atividades` WRITE;
/*!40000 ALTER TABLE `log_atividades` DISABLE KEYS */;
INSERT INTO `log_atividades` VALUES (1,6,'doacoes_page','GET /doacoes_page','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:33:31'),(2,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:33:31'),(3,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:33:44'),(4,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:33:44'),(5,6,'doacoes_page','GET /doacoes_page','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:33:46'),(6,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:33:46'),(7,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:34:16'),(8,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:34:19'),(9,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:34:20'),(10,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:34:46'),(11,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:35:16'),(12,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:35:46'),(13,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:36:16'),(14,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:37:12'),(15,6,'listar_notificacoes','GET /notificacoes','192.168.15.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','2025-04-22 00:38:12');
/*!40000 ALTER TABLE `log_atividades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificacoes`
--

DROP TABLE IF EXISTS `notificacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notificacoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `mensagem` text NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `lida` tinyint(1) DEFAULT '0',
  `data_envio` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `notificacoes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificacoes`
--

LOCK TABLES `notificacoes` WRITE;
/*!40000 ALTER TABLE `notificacoes` DISABLE KEYS */;
INSERT INTO `notificacoes` VALUES (1,6,'Nova Campanha: Ajude a ONG Esperança','Participe da campanha de arrecadação para crianças carentes. Qualquer ajuda faz a diferença!','campanha',1,'2025-04-22 23:43:37'),(2,6,'Doe Alimentos - Campanha Solidária','Estamos recolhendo cestas básicas para famílias afetadas pelas chuvas. Contamos com sua colaboração!','campanha',1,'2025-04-22 23:43:37'),(3,6,'Campanha de Inverno 2025','Ajude pessoas em situação de rua neste inverno. Doe roupas e cobertores até o final de abril.','campanha',1,'2025-04-22 23:43:37'),(4,6,'Nova meta: 1000 kits de higiene','Nossa meta é montar 1000 kits de higiene até o dia 30. Contribua com sabonetes, escovas, etc.','campanha',1,'2025-04-22 23:43:37'),(5,6,'Participe do mutirão solidário!','No próximo sábado, faremos um mutirão para distribuir doações. Venha participar como voluntário!','campanha',1,'2025-04-22 23:43:37'),(6,6,'Contribuição Realizada','Sua contribuição de R$ 1.00 para a campanha \'SOS Enchentes RS\' foi registrada com sucesso!','contribuicao',1,'2025-04-22 23:52:29'),(7,6,'Contribuição Realizada','Sua contribuição de R$ 100.00 para a campanha \'SOS Enchentes RS\' foi registrada com sucesso!','contribuicao',1,'2025-04-22 23:52:44'),(8,6,'Contribuição Realizada','Sua contribuição de R$ 123.00 para a campanha \'SOS Enchentes RS\' foi registrada com sucesso!','contribuicao',1,'2025-04-22 23:56:05'),(9,6,'Contribuição Realizada','Sua contribuição de R$ 1111.00 para a campanha \'Campanha de Saúde Rural\' foi registrada com sucesso!','contribuicao',1,'2025-04-23 01:46:58'),(10,6,'Contribuição Realizada','Sua contribuição de R$ 525.00 para a campanha \'livro\' foi registrada com sucesso!','contribuicao',1,'2025-04-23 02:26:18'),(11,6,'Contribuição Realizada','Sua contribuição de R$ 9999.00 para a campanha \'livros\' foi registrada com sucesso!','contribuicao',0,'2025-04-23 22:31:25');
/*!40000 ALTER TABLE `notificacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text,
  `categoria` varchar(50) DEFAULT NULL,
  `quantidade` int NOT NULL DEFAULT '1',
  `usuario_id` int NOT NULL,
  `tipo` enum('doacao','solicitacao') NOT NULL,
  `data_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `produtos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitacoes`
--

DROP TABLE IF EXISTS `solicitacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitacoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text,
  `categoria` varchar(50) DEFAULT NULL,
  `quantidade` int NOT NULL,
  `status` varchar(20) DEFAULT 'pendente',
  `data_solicitacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `solicitacoes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitacoes`
--

LOCK TABLES `solicitacoes` WRITE;
/*!40000 ALTER TABLE `solicitacoes` DISABLE KEYS */;
INSERT INTO `solicitacoes` VALUES (1,5,'livro','','outros',1,'pendente','2025-04-19 20:24:43'),(2,6,'livro','','outros',1,'pendente','2025-04-19 20:27:03'),(3,6,'Calcinhas','','roupas',1,'pendente','2025-04-19 20:30:18'),(4,7,'livro','','outros',1,'pendente','2025-04-20 00:03:23');
/*!40000 ALTER TABLE `solicitacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` enum('doador','admin','instituicao') NOT NULL DEFAULT 'doador',
  `data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `verificado` tinyint(1) DEFAULT '0',
  `token_verificacao` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Administrador','admin@sistema.com','admin123','admin','2025-04-18 18:13:24',0,NULL),(2,'Oraculo','TESTE@GMAIL.COM','g1wqfwfwfq','doador','2025-04-19 15:50:51',0,NULL),(3,'Admin1','TESTE1@GMAIL.COM','casa2','doador','2025-04-19 16:06:34',0,NULL),(4,'teste','TESTE3@GMAIL.COM','scrypt:32768:8:1$pKl1eLrV2kz7mUzi$cda4de4fe0f3a1e634a62a70cc9acc16595ada2b3ee694a9b58e15b2d3af538fb46674a5a64f0e08c6b443bbe96b6c320ec1de123c8fdde1cd55c9cb2dab29f8','doador','2025-04-19 17:18:02',0,NULL),(5,'Admin1','TESTE4@GMAIL.COM','manodoxceu','doador','2025-04-19 20:23:02',0,NULL),(6,'user','teste0@gmail.com','abc123','doador','2025-04-19 20:26:03',0,NULL),(7,'user2','TESTE2@GMAIL.COM','abc123','doador','2025-04-20 00:02:37',0,NULL),(8,'user1','user1@gmail.com','anc123','doador','2025-04-22 00:23:14',0,'a90a5ecb-cd90-4d0b-a9a9-f20adb0d83f1'),(9,'carlos','1teste@gmail.com','abc123','doador','2025-04-23 22:28:39',0,NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-23 20:04:12

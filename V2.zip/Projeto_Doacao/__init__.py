# ==================== __init__.py (raiz do projeto) ====================
"""
Sistema de Doações - Projeto Flask
Sistema para gerenciamento de doações, solicitações e campanhas
"""

__version__ = "1.0.0"
__author__ = "Sistema de Doações Team"

# ==================== routes/__init__.py ====================
"""
Módulo de rotas do sistema de doações
Contém todos os blueprints e endpoints da aplicação
"""

from .auth import auth_bp
from .doacoes import doacoes_bp
from .solicitacoes import solicitacoes_bp
from .campanhas import campanhas_bp
from .notificacoes import notificacoes_bp

__all__ = [
    'auth_bp',
    'doacoes_bp', 
    'solicitacoes_bp',
    'campanhas_bp',
    'notificacoes_bp'
]
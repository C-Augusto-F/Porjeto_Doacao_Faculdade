# ==================== routes/auth.py ====================
from flask import Blueprint, render_template, request, jsonify, session, send_from_directory
import os
from config.database import get_db_connection

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/static/<path:filename>')
def static_files(filename):
    from flask import current_app
    return send_from_directory(current_app.static_folder, filename)

@auth_bp.route('/js/<path:filename>')
def js_files(filename):
    from flask import current_app
    return send_from_directory(os.path.join(current_app.static_folder, 'js'), filename)

@auth_bp.route('/')
def index():
    return render_template('index.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'Dados inválidos'}), 400

            email = data.get('email')
            senha = data.get('password')

            with get_db_connection() as (conexao, cursor):
                cursor.execute(
                    "SELECT id, nome FROM usuarios WHERE email = %s AND senha = %s",
                    (email, senha)
                )
                usuario = cursor.fetchone()

                if usuario:
                    session['usuario_id'] = usuario['id']
                    session['usuario_nome'] = usuario['nome']
                    return jsonify({
                        'message': 'Login realizado com sucesso',
                        'user': {'id': usuario['id'], 'nome': usuario['nome']}
                    }), 200
                else:
                    return jsonify({'error': 'Credenciais inválidas'}), 401

        except Exception as e:
            return jsonify({'error': str(e)}), 500

    return render_template('login.html')

@auth_bp.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'Dados inválidos'}), 400

            nome = data.get('name')
            email = data.get('email')
            senha = data.get('password')

            if not all([nome, email, senha]):
                return jsonify({'error': 'Todos os campos são obrigatórios'}), 400

            with get_db_connection() as (conexao, cursor):
                cursor.execute("SELECT id FROM usuarios WHERE email = %s", (email,))
                if cursor.fetchone():
                    return jsonify({'error': 'Email já cadastrado'}), 400

                cursor.execute(
                    "INSERT INTO usuarios (nome, email, senha, tipo) VALUES (%s, %s, %s, 'doador')",
                    (nome, email, senha)
                )
                conexao.commit()

                return jsonify({'message': 'Cadastro realizado com sucesso'}), 201

        except Exception as e:
            return jsonify({'error': str(e)}), 500

    return render_template('cadastro.html')

@auth_bp.route('/usuario_info', methods=['GET'])
def usuario_info():
    from utils.decorators import login_required
    @login_required
    def _usuario_info():
        return jsonify({
            'id': session.get('usuario_id'),
            'nome': session.get('usuario_nome')
        })
    return _usuario_info()

@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logout realizado com sucesso'})
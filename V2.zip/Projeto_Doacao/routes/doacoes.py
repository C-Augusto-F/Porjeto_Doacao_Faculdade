# ==================== routes/doacoes.py ====================
from flask import Blueprint, render_template, request, jsonify, session
from utils.decorators import login_required
from config.database import get_db_connection
from datetime import datetime

doacoes_bp = Blueprint('doacoes', __name__)

@doacoes_bp.route('/doacoes_page')
@login_required
def doacoes_page():
    return render_template('doacoes.html')

@doacoes_bp.route('/doacoes', methods=['GET', 'POST'])
@login_required
def doacoes():
    if request.method == 'GET':
        try:
            with get_db_connection() as (conexao, cursor):
                cursor.execute(
                    "SELECT id, nome, descricao, categoria, quantidade, DATE_FORMAT(data_doacao, '%Y-%m-%d') as data_doacao FROM doacoes WHERE usuario_id = %s", 
                    (session['usuario_id'],)
                )
                doacoes = cursor.fetchall()
                return jsonify(doacoes), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
            
    elif request.method == 'POST':
        try:
            data = request.get_json()
            nome = data.get('nome')
            quantidade = data.get('quantidade')
            descricao = data.get('descricao', '')
            categoria = data.get('categoria', 'outros')

            if not nome or not quantidade:
                return jsonify({'error': 'Nome e quantidade são obrigatórios'}), 400

            with get_db_connection() as (conexao, cursor):
                cursor.execute(
                    "INSERT INTO doacoes (nome, descricao, categoria, quantidade, usuario_id) VALUES (%s, %s, %s, %s, %s)",
                    (nome, descricao, categoria, quantidade, session['usuario_id'])
                )
                conexao.commit()
                return jsonify({'message': 'Doação registrada com sucesso'}), 201
        except Exception as e:
            return jsonify({'error': str(e)}), 500

@doacoes_bp.route('/doacoes/<int:id>', methods=['PUT', 'DELETE'])
@login_required
def gerenciar_doacao(id):
    if request.method == 'PUT':
        try:
            data = request.get_json()
            nome = data.get('nome')
            quantidade = data.get('quantidade')
            descricao = data.get('descricao', '')
            categoria = data.get('categoria', 'outros')

            with get_db_connection() as (conexao, cursor):
                cursor.execute(
                    "UPDATE doacoes SET nome=%s, quantidade=%s, descricao=%s, categoria=%s WHERE id=%s AND usuario_id=%s",
                    (nome, quantidade, descricao, categoria, id, session['usuario_id'])
                )
                conexao.commit()
                return jsonify({'message': 'Doação atualizada com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
            
    elif request.method == 'DELETE':
        try:
            with get_db_connection() as (conexao, cursor):
                cursor.execute("DELETE FROM doacoes WHERE id=%s AND usuario_id=%s", (id, session['usuario_id']))
                conexao.commit()
                return jsonify({'message': 'Doação excluída com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500

@doacoes_bp.route('/itens_disponiveis')
@login_required
def itens_disponiveis():
    return render_template('itens_disponiveis.html')

@doacoes_bp.route('/doacoes/disponiveis')
@login_required
def listar_doacoes_disponiveis():
    try:
        with get_db_connection() as (conexao, cursor):
            cursor.execute(
                """
                SELECT d.id, d.nome, d.descricao, d.categoria, d.quantidade, 
                       DATE_FORMAT(d.data_doacao, '%Y-%m-%d') as data_doacao,
                       u.nome as doador
                FROM doacoes d
                JOIN usuarios u ON d.usuario_id = u.id
                WHERE d.usuario_id != %s AND d.quantidade > 0
                ORDER BY d.data_doacao DESC
                """, 
                (session['usuario_id'],)
            )
            doacoes = cursor.fetchall()
            return jsonify(doacoes), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@doacoes_bp.route('/doacoes/estatisticas')
@login_required
def doacoes_estatisticas():
    try:
        with get_db_connection() as (conexao, cursor):
            # Contar total de produtos doados
            cursor.execute("SELECT COALESCE(SUM(quantidade), 0) as total FROM produtos WHERE tipo = 'doacao'")
            total_doados = cursor.fetchone()['total']
            
            # Contar total de solicitações pendentes
            cursor.execute("SELECT COUNT(*) as total FROM solicitacoes WHERE status = 'pendente'")
            total_solicitacoes = cursor.fetchone()['total']
            
            # Estatísticas por categoria
            cursor.execute("""
                SELECT categoria, COUNT(*) as total, SUM(quantidade) as quantidade_total 
                FROM produtos 
                WHERE tipo = 'doacao' 
                GROUP BY categoria
            """)
            estatisticas_categorias = cursor.fetchall()
            
            # Estatísticas por status das solicitações
            cursor.execute("""
                SELECT status, COUNT(*) as total 
                FROM solicitacoes 
                GROUP BY status
            """)
            estatisticas_status = cursor.fetchall()
            
            return jsonify({
                "total_doados": total_doados,
                "total_solicitacoes": total_solicitacoes,
                "categorias": estatisticas_categorias,
                "status_solicitacoes": estatisticas_status
            })
            
    except Exception as e:
        return jsonify({"error": "Erro interno do servidor"}), 500
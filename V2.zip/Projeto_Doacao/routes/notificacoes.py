# ==================== routes/notificacoes.py ====================
from flask import Blueprint, render_template, request, jsonify, session
from utils.decorators import login_required
from config.database import get_db_connection

notificacoes_bp = Blueprint('notificacoes', __name__)

@notificacoes_bp.route('/notificacoes_page')
@login_required
def notificacoes_page():
    return render_template('notificacoes.html')

@notificacoes_bp.route('/notificacoes', methods=['GET'])
@login_required
def listar_notificacoes():
    try:
        with get_db_connection() as (conexao, cursor):
            cursor.execute("""
                SELECT id, titulo, mensagem, tipo, lida, 
                       DATE_FORMAT(data_envio, '%d/%m/%Y %H:%i') as data_criacao
                FROM notificacoes 
                WHERE usuario_id = %s
                ORDER BY data_envio DESC, lida ASC
            """, (session['usuario_id'],))
            
            notificacoes = cursor.fetchall()
            
            # Conta notificações não lidas
            cursor.execute(
                "SELECT COUNT(*) as nao_lidas FROM notificacoes WHERE usuario_id = %s AND lida = 0", 
                (session['usuario_id'],)
            )
            
            contagem = cursor.fetchone()
            
            return jsonify({
                'notificacoes': notificacoes,
                'nao_lidas': contagem['nao_lidas'] if contagem else 0
            }), 200
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@notificacoes_bp.route('/notificacoes/marcar_lida/<int:id>', methods=['PUT'])
@login_required
def marcar_notificacao_lida(id):
    try:
        with get_db_connection() as (conexao, cursor):
            cursor.execute(
                "UPDATE notificacoes SET lida = 1 WHERE id = %s AND usuario_id = %s",
                (id, session['usuario_id'])
            )
            conexao.commit()
            
            return jsonify({'message': 'Notificação marcada como lida'}), 200
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@notificacoes_bp.route('/notificacoes/contagem', methods=['GET'])
@login_required
def contagem_notificacoes():
    try:
        with get_db_connection() as (conexao, cursor):
            cursor.execute(
                "SELECT COUNT(*) as nao_lidas FROM notificacoes WHERE usuario_id = %s AND lida = 0", 
                (session['usuario_id'],)
            )
            
            contagem = cursor.fetchone()
            
            return jsonify({
                'nao_lidas': contagem['nao_lidas'] if contagem else 0
            }), 200
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500
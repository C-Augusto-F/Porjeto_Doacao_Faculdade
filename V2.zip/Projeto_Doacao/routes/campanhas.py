# ==================== routes/campanhas.py ====================
from flask import Blueprint, render_template, request, jsonify, session
from utils.decorators import login_required
from config.database import get_db_connection

campanhas_bp = Blueprint('campanhas', __name__)

@campanhas_bp.route('/campanhas_page')
@login_required
def campanhas_page():
    return render_template('campanhas.html')

@campanhas_bp.route('/campanhas', methods=['GET', 'POST'])
@login_required
def campanhas():
    if request.method == 'GET':
        try:
            with get_db_connection() as (conexao, cursor):
                cursor.execute("""
                    SELECT id, nome, descricao, DATE_FORMAT(data_inicio, '%Y-%m-%d') as data_inicio, 
                           DATE_FORMAT(data_fim, '%Y-%m-%d') as data_fim, 
                           meta_financeira, valor_arrecadado, status
                    FROM campanhas 
                    WHERE status = 'ativa'
                    ORDER BY data_inicio DESC
                """)
                campanhas = cursor.fetchall()
                return jsonify(campanhas), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
            
    elif request.method == 'POST':
        try:
            data = request.get_json()
            nome = data.get('nome')
            descricao = data.get('descricao')
            data_inicio = data.get('data_inicio')
            data_fim = data.get('data_fim')
            meta_financeira = float(data.get('meta_financeira', 0))

            if not all([nome, descricao, data_inicio, data_fim, meta_financeira]):
                return jsonify({'error': 'Todos os campos são obrigatórios'}), 400

            with get_db_connection() as (conexao, cursor):
                cursor.execute("""
                    INSERT INTO campanhas (nome, descricao, data_inicio, data_fim, meta_financeira)
                    VALUES (%s, %s, %s, %s, %s)
                """, (nome, descricao, data_inicio, data_fim, meta_financeira))
                conexao.commit()
                return jsonify({'message': 'Campanha criada com sucesso!'}), 201

        except Exception as e:
            return jsonify({'error': str(e)}), 500

@campanhas_bp.route('/campanhas/<int:id>', methods=['PUT', 'DELETE'])
@login_required
def gerenciar_campanha(id):
    if request.method == 'PUT':
        try:
            data = request.get_json()
            nome = data.get('nome')
            descricao = data.get('descricao')
            data_inicio = data.get('data_inicio')
            data_fim = data.get('data_fim')
            meta_financeira = data.get('meta_financeira')
            status = data.get('status')

            if not all([nome, descricao, data_inicio, data_fim, meta_financeira, status]):
                return jsonify({'error': 'Todos os campos são obrigatórios'}), 400

            with get_db_connection() as (conexao, cursor):
                cursor.execute(
                    "UPDATE campanhas SET nome=%s, descricao=%s, data_inicio=%s, data_fim=%s, meta_financeira=%s, status=%s WHERE id=%s",
                    (nome, descricao, data_inicio, data_fim, meta_financeira, status, id)
                )
                conexao.commit()
                return jsonify({'message': 'Campanha atualizada com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
            
    elif request.method == 'DELETE':
        try:
            with get_db_connection() as (conexao, cursor):
                cursor.execute("DELETE FROM campanhas WHERE id=%s", (id,))
                conexao.commit()
                return jsonify({'message': 'Campanha excluída com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500

@campanhas_bp.route('/campanhas/<int:id>/contribuir', methods=['POST'])
@login_required
def contribuir_campanha(id):
    try:
        data = request.get_json()
        valor = float(data.get('valor', 0))
        
        if valor <= 0:
            return jsonify({'error': 'Valor deve ser maior que zero'}), 400

        with get_db_connection() as (conexao, cursor):
            conexao.start_transaction()
            
            # Verificar se a campanha existe e está ativa
            cursor.execute(
                "SELECT id, nome, status FROM campanhas WHERE id = %s", 
                (id,)
            )
            
            campanha = cursor.fetchone()
            
            if not campanha:
                return jsonify({'error': 'Campanha não encontrada'}), 404
                
            if campanha['status'] != 'ativa':
                return jsonify({'error': 'Esta campanha não está mais ativa'}), 400
            
            # Atualizar valor arrecadado
            cursor.execute(
                "UPDATE campanhas SET valor_arrecadado = valor_arrecadado + %s WHERE id = %s",
                (valor, id)
            )
            
            # Registrar a contribuição
            cursor.execute(
                """
                INSERT INTO contribuicoes (usuario_id, campanha_id, valor, data_contribuicao)
                VALUES (%s, %s, %s, NOW())
                """,
                (session['usuario_id'], id, valor)
            )
            
            contribuicao_id = cursor.lastrowid
            
            # Criar notificação
            cursor.execute(
                """
                INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
                VALUES (%s, %s, %s, 'contribuicao')
                """,
                (
                    session['usuario_id'], 
                    "Contribuição Realizada", 
                    f"Sua contribuição de R$ {valor:.2f} para a campanha '{campanha['nome']}' foi registrada com sucesso!"
                )
            )
            
            conexao.commit()
            
            return jsonify({
                'message': 'Contribuição realizada com sucesso',
                'contribuicao_id': contribuicao_id
            }), 201
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500
# ==================== routes/solicitacoes.py ====================
from flask import Blueprint, render_template, request, jsonify, session
from utils.decorators import login_required
from config.database import get_db_connection

solicitacoes_bp = Blueprint('solicitacoes', __name__)

@solicitacoes_bp.route('/solicitacoes_page')
@login_required
def solicitacoes_page():
    return render_template('solicitacoes.html')

@solicitacoes_bp.route('/solicitacoes', methods=['GET', 'POST'])
@login_required
def solicitacoes():
    if request.method == 'GET':
        try:
            with get_db_connection() as (conexao, cursor):
                cursor.execute(
                    "SELECT id, nome, descricao, categoria, quantidade, status, DATE_FORMAT(data_solicitacao, '%Y-%m-%d') as data_solicitacao FROM solicitacoes WHERE usuario_id = %s", 
                    (session['usuario_id'],)
                )
                solicitacoes = cursor.fetchall()
                return jsonify(solicitacoes), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
            
    elif request.method == 'POST':
        try:
            data = request.get_json()
            nome = data.get('nome')
            quantidade = data.get('quantidade')
            descricao = data.get('descricao', '')
            categoria = data.get('categoria', 'outros')

            if not nome or not quantidade:
                return jsonify({'error': 'Nome e quantidade são obrigatórios'}), 400

            with get_db_connection() as (conexao, cursor):
                cursor.execute(
                    "INSERT INTO solicitacoes (nome, descricao, categoria, quantidade, usuario_id, status) VALUES (%s, %s, %s, %s, %s, 'pendente')",
                    (nome, descricao, categoria, quantidade, session['usuario_id'])
                )
                conexao.commit()
                return jsonify({'message': 'Solicitação registrada com sucesso'}), 201
        except Exception as e:
            return jsonify({'error': str(e)}), 500

@solicitacoes_bp.route('/solicitacoes/<int:id>', methods=['PUT', 'DELETE'])
@login_required
def gerenciar_solicitacao(id):
    if request.method == 'PUT':
        try:
            data = request.get_json()
            nome = data.get('nome')
            quantidade = data.get('quantidade')
            descricao = data.get('descricao', '')
            categoria = data.get('categoria', 'outros')
            status = data.get('status', 'pendente')

            with get_db_connection() as (conexao, cursor):
                cursor.execute(
                    "UPDATE solicitacoes SET nome=%s, quantidade=%s, descricao=%s, categoria=%s, status=%s WHERE id=%s AND usuario_id=%s",
                    (nome, quantidade, descricao, categoria, status, id, session['usuario_id'])
                )
                conexao.commit()
                return jsonify({'message': 'Solicitação atualizada com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
            
    elif request.method == 'DELETE':
        try:
            with get_db_connection() as (conexao, cursor):
                cursor.execute("DELETE FROM solicitacoes WHERE id=%s AND usuario_id=%s", (id, session['usuario_id']))
                conexao.commit()
                return jsonify({'message': 'Solicitação excluída com sucesso'}), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500

@solicitacoes_bp.route('/solicitacoes/criar', methods=['POST'])
@login_required
def criar_solicitacao():
    try:
        data = request.get_json()
        doacao_id = data.get('doacao_id')
        quantidade = int(data.get('quantidade'))
        motivo = data.get('motivo', '')

        if not doacao_id or not quantidade:
            return jsonify({'error': 'Doação ID e quantidade são obrigatórios'}), 400

        with get_db_connection() as (conexao, cursor):
            conexao.start_transaction()
            
            # Verificar se a doação existe e tem quantidade suficiente
            cursor.execute(
                "SELECT id, nome, quantidade, usuario_id FROM doacoes WHERE id = %s", 
                (doacao_id,)
            )
            
            doacao = cursor.fetchone()
            
            if not doacao:
                return jsonify({'error': 'Doação não encontrada'}), 404
                
            if doacao['usuario_id'] == session['usuario_id']:
                return jsonify({'error': 'Você não pode solicitar sua própria doação'}), 400
                
            if doacao['quantidade'] < quantidade:
                return jsonify({'error': 'Quantidade solicitada maior que a disponível'}), 400
            
            # Criar a solicitação
            cursor.execute(
                """
                INSERT INTO solicitacoes 
                (usuario_id, nome, descricao, categoria, quantidade, status, doacao_id) 
                SELECT %s, d.nome, %s, d.categoria, %s, 'pendente', d.id
                FROM doacoes d WHERE d.id = %s
                """,
                (session['usuario_id'], motivo, quantidade, doacao_id)
            )
            
            solicitacao_id = cursor.lastrowid
            
            # Buscar nome do usuário solicitante
            cursor.execute("SELECT nome FROM usuarios WHERE id = %s", (session['usuario_id'],))
            usuario = cursor.fetchone()
            
            # Criar notificações
            cursor.execute(
                """
                INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
                VALUES (%s, %s, %s, 'solicitacao')
                """,
                (
                    doacao['usuario_id'], 
                    "Nova Solicitação de Doação", 
                    f"{usuario['nome']} solicitou {quantidade} unidade(s) do item '{doacao['nome']}' que você disponibilizou para doação."
                )
            )
            
            cursor.execute(
                """
                INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
                VALUES (%s, %s, %s, 'solicitacao_enviada')
                """,
                (
                    session['usuario_id'], 
                    "Solicitação Enviada", 
                    f"Sua solicitação para o item '{doacao['nome']}' foi enviada com sucesso. Aguarde a resposta do doador."
                )
            )
            
            conexao.commit()
            
            return jsonify({
                'message': 'Solicitação criada com sucesso',
                'solicitacao_id': solicitacao_id
            }), 201
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500
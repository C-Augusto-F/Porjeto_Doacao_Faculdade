from flask import Flask
from flask_cors import CORS
import secrets
import os

# Importar blueprints
from routes.auth import auth_bp
from routes.doacoes import doacoes_bp
from routes.solicitacoes import solicitacoes_bp
from routes.campanhas import campanhas_bp
from routes.notificacoes import notificacoes_bp

def create_app():
    app = Flask(__name__, static_folder='static', template_folder='templates')
    
    # Configuração
    app.secret_key = secrets.token_hex(16)
    
    # Configuração CORS
    CORS(app, resources={
        r"/*": {
            "origins": ["http://localhost:5000"],
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"],
            "supports_credentials": True
        }
    })
    
    # Registrar blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(doacoes_bp)
    app.register_blueprint(solicitacoes_bp)
    app.register_blueprint(campanhas_bp)
    app.register_blueprint(notificacoes_bp)
    
    # Headers de cache
    @app.after_request
    def add_no_cache_headers(response):
        from flask import request
        if request.endpoint != 'static':
            response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
            response.headers['Pragma'] = 'no-cache'
            response.headers['Expires'] = '0'
        return response
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)
document.addEventListener('DOMContentLoaded', () => {
    const cadastroForm = document.getElementById('cadastroForm');
    
    if (cadastroForm) {
        cadastroForm.addEventListener('submit', async (e) => {
            try {
                await handleFormSubmit(e, '/cadastro', '/login');
            } catch (error) {
                const mensagem = document.getElementById('mensagem');
                if (mensagem) {
                    mensagem.textContent = error.message;
                    mensagem.className = 'erro';
                }
            }
        });
    }
});
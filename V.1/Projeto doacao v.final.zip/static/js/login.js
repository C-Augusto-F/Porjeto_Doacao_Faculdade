document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(loginForm);
            const data = {
                email: formData.get('email'),
                password: formData.get('password')
            };

            try {
                const response = await fetch('/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data),
                    credentials: 'include'
                });

                const result = await response.json();
                
                if (!response.ok) {
                    throw new Error(result.error || 'Erro no login');
                }
                
                window.location.href = '/doacoes_page';
            } catch (error) {
                const mensagem = document.getElementById('mensagem');
                if (mensagem) {
                    mensagem.textContent = error.message;
                    mensagem.className = 'erro';
                } else {
                    alert(error.message);
                }
            }
        });
    }
});
// notificacoes.js - Gerencia a listagem e interação com notificações
document.addEventListener('DOMContentLoaded', function() {
    // Elementos da DOM
    const notificacoesLista = document.getElementById('notificacoes-lista');
    const loadingElement = document.getElementById('loading-notificacoes');
    const errorElement = document.getElementById('error-message');
    const semNotificacoesElement = document.getElementById('sem-notificacoes');
    
    // Botão de logout
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            fetch('/logout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'same-origin'
            })
            .then(response => response.json())
            .then(data => {
                window.location.href = '/login';
            })
            .catch(error => console.error('Erro ao fazer logout:', error));
        });
    }
    
    // Carregar notificações ao iniciar a página
    carregarNotificacoes();
    
    function carregarNotificacoes() {
        loadingElement.style.display = 'block';
        errorElement.style.display = 'none';
        semNotificacoesElement.style.display = 'none';
        
        fetch('/notificacoes', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'same-origin'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao carregar notificações');
            }
            return response.json();
        })
        .then(data => {
            loadingElement.style.display = 'none';
            
            if (data.notificacoes.length === 0) {
                semNotificacoesElement.style.display = 'block';
                return;
            }
            
            renderizarNotificacoes(data.notificacoes);
            // Atualizar o contador no badge
            atualizarContagemNotificacoes();
        })
        .catch(error => {
            loadingElement.style.display = 'none';
            errorElement.textContent = error.message || 'Erro ao carregar notificações';
            errorElement.style.display = 'block';
            console.error('Erro:', error);
        });
    }
    
    function renderizarNotificacoes(notificacoes) {
        notificacoesLista.innerHTML = '';
        
        notificacoes.forEach(notificacao => {
            const statusClasse = notificacao.lida ? 'lida' : 'nao-lida';
            const tipoClasse = `tipo-${notificacao.tipo || 'sistema'}`;
            const tipoTexto = traduzirTipoNotificacao(notificacao.tipo);
            
            const notificacaoHTML = `
                <div class="notificacao ${statusClasse}" data-id="${notificacao.id}">
                    <div class="notificacao-conteudo">
                        <span class="notificacao-tipo ${tipoClasse}">${tipoTexto}</span>
                        <h3 class="notificacao-titulo">${notificacao.titulo}</h3>
                        <p class="notificacao-mensagem">${notificacao.mensagem}</p>
                        <span class="notificacao-data">${notificacao.data_criacao}</span>
                    </div>
                    ${!notificacao.lida ? `
                        <button class="btn-small btn-primary marcar-lida-btn" data-id="${notificacao.id}">
                            Marcar como lida
                        </button>
                    ` : ''}
                </div>
            `;
            
            notificacoesLista.innerHTML += notificacaoHTML;
        });
        
        // Adicionar event listeners aos botões
        document.querySelectorAll('.marcar-lida-btn').forEach(button => {
            button.addEventListener('click', function() {
                const notificacaoId = this.getAttribute('data-id');
                marcarComoLida(notificacaoId);
            });
        });
    }
    
    function marcarComoLida(notificacaoId) {
        fetch(`/notificacoes/marcar_lida/${notificacaoId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'same-origin'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao marcar notificação como lida');
            }
            return response.json();
        })
        .then(data => {
            // Atualizar visualmente a notificação
            const notificacaoElement = document.querySelector(`.notificacao[data-id="${notificacaoId}"]`);
            if (notificacaoElement) {
                notificacaoElement.classList.remove('nao-lida');
                notificacaoElement.classList.add('lida');
                
                const btnMarcarLida = notificacaoElement.querySelector('.marcar-lida-btn');
                if (btnMarcarLida) {
                    btnMarcarLida.remove();
                }
            }
            
            // Atualizar o contador de notificações
            atualizarContagemNotificacoes();
        })
        .catch(error => {
            console.error('Erro:', error);
            alert(error.message || 'Erro ao marcar notificação como lida');
        });
    }
    
    function traduzirTipoNotificacao(tipo) {
        const traducoes = {
            'solicitacao': 'Solicitação',
            'solicitacao_enviada': 'Solicitação Enviada',
            'contribuicao': 'Contribuição',
            'alerta': 'Alerta',
            'sistema': 'Sistema'
        };
        
        return traducoes[tipo] || 'Sistema';
    }
});
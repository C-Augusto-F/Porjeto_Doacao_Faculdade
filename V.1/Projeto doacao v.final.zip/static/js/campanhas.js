// campanhas.js - Gerencia as campanhas e contribuições
document.addEventListener('DOMContentLoaded', function() {
    // Elementos da DOM
    const campanhasContainer = document.getElementById('campanhas-container');
    const loadingElement = document.getElementById('loading');
    const errorElement = document.getElementById('error-message');
    const semResultadosElement = document.getElementById('sem-resultados');
    
    // Botão de logout
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            fetch('/logout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'same-origin'
            })
            .then(response => response.json())
            .then(data => {
                window.location.href = '/login';
            })
            .catch(error => console.error('Erro ao fazer logout:', error));
        });
    }
    
    // Carregar campanhas ao iniciar a página
    carregarCampanhas();
    
    function carregarCampanhas() {
        loadingElement.style.display = 'block';
        errorElement.style.display = 'none';
        semResultadosElement.style.display = 'none';
        
        fetch('/campanhas', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'same-origin'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao carregar campanhas');
            }
            return response.json();
        })
        .then(campanhas => {
            loadingElement.style.display = 'none';
            
            if (campanhas.length === 0) {
                semResultadosElement.style.display = 'block';
                return;
            }
            
            renderizarCampanhas(campanhas);
        })
        .catch(error => {
            loadingElement.style.display = 'none';
            errorElement.textContent = error.message || 'Erro ao carregar campanhas';
            errorElement.style.display = 'block';
            console.error('Erro:', error);
        });
    }
    
    function renderizarCampanhas(campanhas) {
        campanhasContainer.innerHTML = '';
        
        campanhas.forEach(campanha => {
            // Calcular progresso
            const progresso = Math.min(Math.round((campanha.valor_arrecadado / campanha.meta_financeira) * 100), 100);
            
            // Formatação de valores
            const metaFormatada = formatarValorMoeda(campanha.meta_financeira);
            const arrecadadoFormatado = formatarValorMoeda(campanha.valor_arrecadado);
            
            const cardHTML = `
                <div class="campanha-card" data-id="${campanha.id}">
                    <div class="campanha-header">
                        <h3>${campanha.nome}</h3>
                        <span class="campanha-status">${campanha.status.toUpperCase()}</span>
                    </div>
                    
                    <div class="campanha-info">
                        <p>${campanha.descricao}</p>
                    </div>
                    
                    <div class="campanha-dates">
                        <span>Início: ${formatarData(campanha.data_inicio)}</span>
                        <span>Término: ${formatarData(campanha.data_fim)}</span>
                    </div>
                    
                    <div class="progress-container">
                        <div class="progress-bar" style="width: ${progresso}%"></div>
                    </div>
                    
                    <div style="text-align: center; margin: 5px 0;">
                        <span>${arrecadadoFormatado} de ${metaFormatada} (${progresso}%)</span>
                    </div>
                    
                    <div class="campanha-actions">
                        <button class="detalhes-btn">Ver Detalhes</button>
                        
                        <div class="contribuir-form">
                            <input type="number" placeholder="Valor R$" min="1" step="0.01" class="valor-contribuicao">
                            <button class="contribuir-btn" data-id="${campanha.id}">Contribuir</button>
                        </div>
                    </div>
                </div>
            `;
            
            campanhasContainer.innerHTML += cardHTML;
        });
        
        // Adicionar event listeners após renderizar o conteúdo
        adicionarEventListeners();
    }
    
    function adicionarEventListeners() {
        // Event listeners para botões de contribuir
        document.querySelectorAll('.contribuir-btn').forEach(button => {
            button.addEventListener('click', function() {
                const campanhaId = this.getAttribute('data-id');
                const inputValor = this.closest('.contribuir-form').querySelector('.valor-contribuicao');
                const valor = parseFloat(inputValor.value);
                
                if (!valor || valor <= 0) {
                    alert('Por favor, insira um valor válido para contribuir.');
                    return;
                }
                
                contribuirCampanha(campanhaId, valor);
            });
        });
        
        // Event listeners para botões de detalhes (para futura implementação)
        document.querySelectorAll('.detalhes-btn').forEach(button => {
            button.addEventListener('click', function() {
                const campanhaCard = this.closest('.campanha-card');
                const campanhaId = campanhaCard.getAttribute('data-id');
                
                // Por enquanto só mostra um alerta, pode expandir para mostrar mais detalhes
                alert('Funcionalidade de detalhes completos a ser implementada em breve.');
            });
        });
    }
    
    function contribuirCampanha(campanhaId, valor) {
        fetch(`/campanhas/${campanhaId}/contribuir`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'same-origin',
            body: JSON.stringify({ valor: valor })
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || 'Erro ao contribuir para a campanha');
                });
            }
            return response.json();
        })
        .then(data => {
            alert('Contribuição realizada com sucesso! Obrigado por sua doação.');
            // Recarregar campanhas para atualizar os valores
            carregarCampanhas();
            // Atualizar o contador de notificações
            atualizarContagemNotificacoes();
        })
        .catch(error => {
            alert(error.message || 'Erro ao processar sua contribuição. Tente novamente.');
            console.error('Erro:', error);
        });
    }
    
    // Funções utilitárias
    function formatarData(dataStr) {
        if (!dataStr) return 'N/A';
        
        const data = new Date(dataStr);
        return data.toLocaleDateString('pt-BR');
    }
    
    function formatarValorMoeda(valor) {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(valor);
    }
});
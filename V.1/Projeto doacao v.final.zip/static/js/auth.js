// Funções utilitárias compartilhadas
async function handleFormSubmit(event, endpoint, successRedirect) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
            credentials: 'include'
        });

        const result = await response.json();
        
        if (response.ok) {
            if (successRedirect) {
                window.location.href = successRedirect;
            }
            return result;
        } else {
            throw new Error(result.error || 'Erro desconhecido');
        }
    } catch (error) {
        console.error('Erro:', error);
        alert(error.message);
        throw error;
    }
}
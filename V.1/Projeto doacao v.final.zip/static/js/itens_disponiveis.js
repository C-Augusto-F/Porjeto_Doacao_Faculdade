document.addEventListener('DOMContentLoaded', function() {
    const doacoesContainer = document.getElementById('doacoes-container');
    const loading = document.getElementById('loading');
    const errorMessage = document.getElementById('error-message');
    const semResultados = document.getElementById('sem-resultados');
    const paginationContainer = document.getElementById('pagination');
    const categoriaFilter = document.getElementById('categoria-filter');
    const buscaInput = document.getElementById('busca');
    const filtrarBtn = document.getElementById('filtrar-btn');
    const solicitarModal = document.getElementById('solicitar-modal');
    const modalClose = document.querySelector('.modal-close');
    const solicitarForm = document.getElementById('solicitar-form');
    const logoutBtn = document.getElementById('logout-btn');
    
    // Verificar se o usuário está logado
    fetch('/usuario_info')
        .then(response => {
            if (!response.ok) {
                window.location.href = '/login';
                throw new Error('Usuário não autenticado');
            }
            return response.json();
        })
        .catch(error => {
            console.error('Erro ao verificar login:', error);
            window.location.href = '/login';
        });
    
    // Configurações de paginação
    let currentPage = 1;
    const itemsPerPage = 6;
    let allDoacoes = [];
    
    // Carregar doações disponíveis
    function carregarDoacoes() {
        loading.style.display = 'block';
        doacoesContainer.style.display = 'none';
        errorMessage.style.display = 'none';
        semResultados.style.display = 'none';
        
        fetch('/doacoes/disponiveis')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Falha ao carregar itens disponíveis');
                }
                return response.json();
            })
            .then(data => {
                allDoacoes = data;
                filtrarDoacoes();
            })
            .catch(error => {
                loading.style.display = 'none';
                errorMessage.textContent = error.message;
                errorMessage.style.display = 'block';
            });
    }
    
    // Filtrar doações
    function filtrarDoacoes() {
        const categoria = categoriaFilter.value;
        const busca = buscaInput.value.toLowerCase();
        
        let doacoesFiltradas = allDoacoes;
        
        if (categoria) {
            doacoesFiltradas = doacoesFiltradas.filter(doacao => doacao.categoria === categoria);
        }
        
        if (busca) {
            doacoesFiltradas = doacoesFiltradas.filter(doacao => 
                doacao.nome.toLowerCase().includes(busca) || 
                (doacao.descricao && doacao.descricao.toLowerCase().includes(busca))
            );
        }
        
        exibirDoacoes(doacoesFiltradas);
    }
    
    // Exibir doações com paginação
    function exibirDoacoes(doacoes) {
        loading.style.display = 'none';
        
        if (doacoes.length === 0) {
            doacoesContainer.style.display = 'none';
            paginationContainer.style.display = 'none';
            semResultados.style.display = 'block';
            return;
        }
        
        const totalPages = Math.ceil(doacoes.length / itemsPerPage);
        const start = (currentPage - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const doacoesPagina = doacoes.slice(start, end);
        
        doacoesContainer.innerHTML = '';
        
        doacoesPagina.forEach(doacao => {
            const card = document.createElement('div');
            card.className = 'doacao-card';
            
            // Função para obter ícone de categoria
            const getCategoriaIcon = (categoria) => {
                const icons = {
                    'alimentos': 'fas fa-utensils',
                    'roupas': 'fas fa-tshirt',
                    'moveis': 'fas fa-couch',
                    'eletronicos': 'fas fa-laptop',
                    'brinquedos': 'fas fa-gamepad',
                    'livros': 'fas fa-book',
                    'medicamentos': 'fas fa-pills',
                    'outros': 'fas fa-box'
                };
                return icons[categoria] || icons.outros;
            };
            
            card.innerHTML = `
                <div class="doacao-header">
                    <h3>${doacao.nome}</h3>
                    <span class="categoria-badge">
                        <i class="${getCategoriaIcon(doacao.categoria)}"></i> 
                        ${capitalizeFirstLetter(doacao.categoria || 'Outros')}
                    </span>
                </div>
                <div class="doacao-body">
                    <div class="doacao-info">
                        <p><i class="fas fa-info-circle"></i> ${doacao.descricao || 'Sem descrição'}</p>
                        <p><i class="fas fa-cubes"></i> Quantidade: ${doacao.quantidade}</p>
                        <p><i class="fas fa-calendar-alt"></i> Disponível desde: ${formatarData(doacao.data_doacao)}</p>
                    </div>
                    <div class="doacao-actions">
                        <button class="solicitar-btn" data-id="${doacao.id}">Solicitar</button>
                        <button class="detalhes-btn" data-id="${doacao.id}">Ver Detalhes</button>
                    </div>
                </div>
            `;
            
            doacoesContainer.appendChild(card);
        });
        
        // Adicionar event listeners aos botões
        document.querySelectorAll('.solicitar-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                abrirModalSolicitacao(id);
            });
        });
        
        document.querySelectorAll('.detalhes-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                verDetalhesDoacao(id);
            });
        });
        
        // Configurar paginação
        configurarPaginacao(totalPages);
        
        doacoesContainer.style.display = 'grid';
        paginationContainer.style.display = 'flex';
        semResultados.style.display = 'none';
    }
    
    // Ver detalhes da doação
    function verDetalhesDoacao(id) {
        const doacao = allDoacoes.find(d => d.id == id);
        if (doacao) {
            alert(`Detalhes do item: ${doacao.nome}\n\nDescrição: ${doacao.descricao || 'Sem descrição'}\nCategoria: ${doacao.categoria}\nQuantidade: ${doacao.quantidade}\nData: ${formatarData(doacao.data_doacao)}`);
        }
    }
    
    // Configurar paginação
    function configurarPaginacao(totalPages) {
        paginationContainer.innerHTML = '';
        
        if (totalPages <= 1) {
            return;
        }
        
        // Botão anterior
        const prevBtn = document.createElement('button');
        prevBtn.innerHTML = '&laquo; Anterior';
        prevBtn.disabled = currentPage === 1;
        prevBtn.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                filtrarDoacoes();
            }
        });
        paginationContainer.appendChild(prevBtn);
        
        // Números de página
        const maxVisiblePages = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
        
        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }
        
        for (let i = startPage; i <= endPage; i++) {
            const pageBtn = document.createElement('button');
            pageBtn.textContent = i;
            pageBtn.className = i === currentPage ? 'active' : '';
            pageBtn.addEventListener('click', () => {
                currentPage = i;
                filtrarDoacoes();
            });
            paginationContainer.appendChild(pageBtn);
        }
        
        // Botão próximo
        const nextBtn = document.createElement('button');
        nextBtn.innerHTML = 'Próximo &raquo;';
        nextBtn.disabled = currentPage === totalPages;
        nextBtn.addEventListener('click', () => {
            if (currentPage < totalPages) {
                currentPage++;
                filtrarDoacoes();
            }
        });
        paginationContainer.appendChild(nextBtn);
    }
    
    // Abrir modal para solicitar doação
    function abrirModalSolicitacao(id) {
        const doacao = allDoacoes.find(d => d.id == id);
        
        if (!doacao) return;
        
        document.getElementById('doacao-id').value = doacao.id;
        document.getElementById('item-nome').value = doacao.nome;
        document.getElementById('item-descricao').value = doacao.descricao || '';
        document.getElementById('item-quantidade').value = doacao.quantidade;
        document.getElementById('quantidade-solicitada').max = doacao.quantidade;
        document.getElementById('quantidade-solicitada').value = 1;
        document.getElementById('motivo').value = '';
        
        solicitarModal.style.display = 'flex';
    }
    
    // Fechar modal
    modalClose.addEventListener('click', () => {
        solicitarModal.style.display = 'none';
    });
    
    // Clicar fora do modal para fechar
    window.addEventListener('click', (e) => {
        if (e.target === solicitarModal) {
            solicitarModal.style.display = 'none';
        }
    });
    
    // Submeter formulário de solicitação
    solicitarForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const doacaoId = document.getElementById('doacao-id').value;
        const quantidadeSolicitada = document.getElementById('quantidade-solicitada').value;
        const motivo = document.getElementById('motivo').value;
        
        // Enviar a solicitação ao backend
        fetch('/solicitacoes/criar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                doacao_id: doacaoId,
                quantidade: quantidadeSolicitada,
                motivo: motivo
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Falha ao enviar solicitação');
            }
            return response.json();
        })
        .then(data => {
            alert('Solicitação enviada com sucesso!');
            solicitarModal.style.display = 'none';
            carregarDoacoes(); // Recarregar a lista
        })
        .catch(error => {
            alert('Erro ao enviar solicitação: ' + error.message);
        });
    });
    
    // Event listener para o botão de filtrar
    filtrarBtn.addEventListener('click', function() {
        currentPage = 1;
        filtrarDoacoes();
    });
    
    // Event listener para pesquisa ao pressionar Enter
    buscaInput.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            currentPage = 1;
            filtrarDoacoes();
        }
    });
    
    // Logout
    logoutBtn.addEventListener('click', function(e) {
        e.preventDefault();
        
        fetch('/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Falha ao fazer logout');
            }
            return response.json();
        })
        .then(data => {
            window.location.href = '/login';
        })
        .catch(error => {
            console.error('Erro ao fazer logout:', error);
        });
    });
    
    // Funções auxiliares
    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    
    function formatarData(dataString) {
        const data = new Date(dataString);
        return data.toLocaleDateString('pt-BR');
    }
    
    // Inicializar a página
    carregarDoacoes();
});